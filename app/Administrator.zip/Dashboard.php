<?php 
namespace App\Controllers\Administrator;

use App\Middleware\Authenticated;
use App\Models\Area;
use App\Models\MonitoringOsView;
use App\Models\pawn_transactionsModel;
use Prophecy\Doubler\ClassPatch\DisableConstructorPatch;
use CodeIgniter\Database\Postgre\Connection;


// use  CodeIgniter\Database\BaseConnection();
class Dashboard extends Authenticated
{

	//  private $db1;
  
    // private $db2;

    public function __construct()
    {
        $this->db1 = db_connect(); // default database group
        $this->dbtests      = \Config\Database::connect('tests');
		$this->dbaccounting = \Config\Database::connect('accounting');
		$session = \Config\Services::session();
		
        // $this->db2 = db_connect("tests"); // other database group
		// $pawn = new pawn_transactionsModel();
		

		if (!$session) {

            redirect('');
        }
    }
	
	
	public function index()
	{
		$area = new Area();
		$view = new MonitoringOsView();
		$data['areas'] = $area->getArea();
		$data['view'] = $view->getViewOs();
		return view('administrator/dashboard/index', $data);
	}

	public function pencairan()
	{
		$area = new Area();
		$view = new MonitoringOsView();
		$data['areas'] = $area->getArea();
		$data['view'] = $view->getViewPencairan();
		return view('administrator/dashboard/pencairan', $data);
	}

	public function repayment()
	{
		$area = new Area();
		$view = new MonitoringOsView();
		$data['areas'] = $area->getArea();
		$data['view'] = $view->getViewRepayment();
		return view('administrator/dashboard/repayment', $data);
	}

	public function dpd()
	{
		$area = new Area();
		$view = new MonitoringOsView();
		$data['areas'] = $area->getArea();
		$data['view'] = $view->getViewDpd();
		return view('administrator/dashboard/dpd', $data);
	}	

	public function saldo()
	{
		$area = new Area();
		$view = new MonitoringOsView();
		$data['areas'] = $area->getArea();
		$data['view'] = $view->getViewSaldo();
		return view('administrator/dashboard/saldo', $data);
	}	

	public function perpanjangan()
	{
		$area = new Area();
		$view = new MonitoringOsView();
		$data['areas'] = $area->getArea();
		$data['view'] = $view->getViewPerpanjangan();
		return view('administrator/dashboard/perpanjangan', $data);
	}

	public function pengeluaran()
	{
		$area = new Area();
		$view = new MonitoringOsView();
		$data['areas'] = $area->getArea();
		$data['view'] = $view->getViewPengeluaran();
		return view('administrator/dashboard/pengeluaran', $data);
	}

	public function oneobligor()
	{
		$area = new Area();
		$view = new MonitoringOsView();
		$data['areas'] = $area->getArea();
		$data['view'] = $view->getViewOneobligor();
		return view('administrator/dashboard/oneobligor', $data);
	}

	public function detail($ktp)
	{
		$area = new Area();
		$view = new MonitoringOsView();
		$data['areas'] = $area->getArea();
		$data['view'] = $view->getViewPencairan();
		$data['ktp'] = $ktp;
		return view('administrator/dashboard/detail', $data);
	}
	
	
}

	
	