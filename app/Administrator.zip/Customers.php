<?php 
namespace App\Controllers\Administrator;


use App\Middleware\Authenticated;

class Customers extends Authenticated
{
	public function index()
	{
		return view('administrator/customers/index');
	}
}
