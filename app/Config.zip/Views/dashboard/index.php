<?php echo $this->extend('layouts/administrator');?>

<?php echo $this->section('content');?>

<section class="section">
        <div class="row">
            <div class="col-xl-4 col-lg-4">
                <div class="card">
                  <div class="card-body card-type-3">
                    <div class="row">
                      <div class="col">
                        <h6 class="text-muted mb-0">Outstanding</h6>
                        <span id= 'countOs' class="font-weight-bold mb-0">450</span>
                      </div>
                      <div class="col-auto">
                        <div class="card-circle l-bg-purple text-white">
                          <i class="fas fa-dollar-sign"></i>
                        </div>
                      </div>
                    </div>
                    <p class="mt-3 mb-0 text-muted text-sm">
                      <span id='noaOs' class="text-success mr-2"><i class="fa fa-arrow-up"></i> 10%</span>
                      <span class="text-nowrap">Noa</span>
                    </p>
                  </div>
                </div>
              </div>
              <div class="col-xl-4 col-lg-4">
                <div class="card">
                  <div class="card-body card-type-3">
                    <div class="row">
                      <div class="col">
                        <h6 class="text-muted mb-0">DPD</h6>
                        <span id='countDpd' class="font-weight-bold mb-0">1,562</span>
                      </div>
                      <div class="col-auto">
                        <div class="card-circle l-bg-cyan text-white">
                          <i class="far fa-chart-bar"></i>
                        </div>
                      </div>
                    </div>
                    <p class="mt-3 mb-0 text-muted text-sm">
                      <span id='noaDpd' class="text-success mr-2"><i class="fa fa-arrow-up"></i> 7.8%</span>
                      <span class="text-nowrap">Noa</span>
                    </p>
                  </div>
                </div>
              </div>
              <div class="col-xl-4 col-lg-4">
                <div class="card">
                  <div class="card-body card-type-3">
                    <div class="row">
                      <div class="col">
                        <h6 class="text-muted mb-0">Deviasi</h6>
                        <span id='countDeviasi' class="font-weight-bold mb-0">7,897</span>
                      </div>
                      <div class="col-auto">
                        <div class="card-circle l-bg-green text-white">
                          <i class="fas fa-briefcase"></i>
                        </div>
                      </div>
                    </div>
                    <p class="mt-3 mb-0 text-muted text-sm">
                      <!-- <span class="text-success mr-2"><i class="fa fa-arrow-up"></i> 15%</span> -->
                      <span class="text-nowrap">Selama Bulan <?php echo date('M'); ?></span>
                    </p>
                  </div>
                </div>
              </div>
              <div class="col-xl-4 col-lg-4">
                <div class="card">
                  <div class="card-body card-type-3">
                    <div class="row">
                      <div class="col">
                        <h6 class="text-muted mb-0">Oneobligor</h6>
                        <span id='countOneobligor' class="font-weight-bold mb-0">$8,965</span>
                      </div>
                      <div class="col-auto">
                        <div class="card-circle l-bg-green text-white">
                          <i class="fas fa-hiking"></i>
                        </div>
                      </div>
                    </div>
                    <p class="mt-3 mb-0 text-muted text-sm">
                      <!-- <span class="text-success mr-2"><i class="fa fa-arrow-up"></i> 5.4%</span>
                      <span class="text-nowrap">Since last month</span> -->
                    </p>
                  </div>
                </div>
              </div>
              <div class="col-xl-4 col-lg-4">
                <div class="card">
                  <div class="card-body card-type-3">
                    <div class="row">
                      <div class="col">
                        <h6 class="text-muted mb-0">LTV</h6>
                        <span id='countLtv' class="font-weight-bold mb-0">7,897</span>
                      </div>
                      <div class="col-auto">
                        <div class="card-circle l-bg-orange text-white">
                          <i class="fas fa-drafting-compass"></i>
                        </div>
                      </div>
                    </div>
                    <p class="mt-3 mb-0 text-muted text-sm">
                      <!-- <span class="text-success mr-2"><i class="fa fa-arrow-up"></i> 15%</span>
                      <span class="text-nowrap">Since last month</span> -->
                    </p>
                  </div>
                </div>
              </div>
              <div class="col-xl-4 col-lg-4">
                <div class="card">
                  <div class="card-body card-type-3">
                    <div class="row">
                      <div class="col">
                        <h6 class="text-muted mb-0">Pembatalan</h6>
                        <span id='countBatal' class="font-weight-bold mb-0">$8,965</span>
                      </div>
                      <div class="col-auto">
                        <div class="card-circle l-bg-red text-white">
                          <i class="fas fa-close"></i>
                        </div>
                      </div>
                    </div>
                    <p class="mt-3 mb-0 text-muted text-sm">
                      <!-- <span class="text-success mr-2"><i class="fa fa-arrow-up"></i> 5.4%</span>
                      <span class="text-nowrap">Since last month</span> -->
                    </p>
                  </div>
                </div>
              </div>
            
            <div  class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12" >
                <div class="card">
                    <div class="card-header">
                    <h4>Outstanding Chart</h4>
                  </div>
                    <div class="card-statistic-4">
                        <div class="align-items-center justify-content-between">
                            <div class="row ">
                                <div class="col-lg-12 col-md- col-sm-12 col-xs-12 pr-0 pt-12">
                                    <div class="card-content">

                                        <div id="chartOutstandingAll" style="height: 370px; max-width: 920px; margin: 0px auto;">
                                        </div>

                                    </div>
                                </div>
                                <div class="col-lg-12 col-md-6 col-sm-6 col-xs-6 pl-0">
                                    <div class="banner-img">
                                        <!-- <img src="<?php echo base_url();?>/assets-panel/img/banner/4.png" alt=""> -->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div  class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-xs-12" >
                <div class="card">
                    <div class="card-header">
                    <h4>DPD Chart</h4>
                  </div>
                    <div class="card-statistic-4">
                        <div class="align-items-center justify-content-between">
                            <div class="row ">
                                <div class="col-lg-12 col-md- col-sm-12 col-xs-12 pr-0 pt-12">
                                    <div class="card-content">

                                        <div id="chartDpd" style="height: 370px; max-width: 920px; margin: 0px auto;">
                                        </div>

                                    </div>
                                </div>
                                <div class="col-lg-12 col-md-6 col-sm-6 col-xs-6 pl-0">
                                    <div class="banner-img">
                                        <!-- <img src="<?php echo base_url();?>/assets-panel/img/banner/4.png" alt=""> -->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
              
            <div  class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-xs-12" >
                <div class="card">
                    <div class="card-header">
                    <h4>Deviasi Chart</h4>
                  </div>
                    <div class="card-statistic-4">
                        <div class="align-items-center justify-content-between">
                            <div class="row ">
                                <div class="col-lg-12 col-md- col-sm-12 col-xs-12 pr-0 pt-12">
                                    <div class="card-content">

                                        <div id="chartDeviasi" style="height: 370px; max-width: 920px; margin: 0px auto;">
                                        </div>

                                    </div>
                                </div>
                                <div class="col-lg-12 col-md-6 col-sm-6 col-xs-6 pl-0">
                                    <div class="banner-img">
                                        <!-- <img src="<?php echo base_url();?>/assets-panel/img/banner/4.png" alt=""> -->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- <div  class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-xs-12" >
                <div class="card">
                    <div class="card-statistic-4">
                        <div class="align-items-center justify-content-between">
                            <div class="row ">
                                <div class="col-lg-12 col-md- col-sm-12 col-xs-12 pr-0 pt-12">
                                    <div class="card-content">

                                        <div id="chartOneobligor" style="height: 370px; max-width: 920px; margin: 0px auto;">
                                        </div>

                                    </div>
                                </div>
                                <div class="col-lg-12 col-md-6 col-sm-6 col-xs-6 pl-0">
                                    <div class="banner-img">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div> -->

            <div  class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-xs-12" >
                <div class="card">
                    <div class="card-header">
                    <h4>LTV Chart</h4>
                  </div>
                    <div class="card-statistic-4">
                        <div class="align-items-center justify-content-between">
                            <div class="row ">
                                <div class="col-lg-12 col-md- col-sm-12 col-xs-12 pr-0 pt-12">
                                    <div class="card-content">

                                        <div id="chartLtv" style="height: 370px; max-width: 920px; margin: 0px auto;">
                                        </div>

                                    </div>
                                </div>
                                <div class="col-lg-12 col-md-6 col-sm-6 col-xs-6 pl-0">
                                    <div class="banner-img">
                                        <!-- <img src="<?php echo base_url();?>/assets-panel/img/banner/4.png" alt=""> -->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div  class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-xs-12" >
                <div class="card">
                    <div class="card-header">
                    <h4>Pembatalan Chart</h4>
                  </div>
                    <div class="card-statistic-4">
                        <div class="align-items-center justify-content-between">
                            <div class="row ">
                                <div class="col-lg-12 col-md- col-sm-12 col-xs-12 pr-0 pt-12">
                                    <div class="card-content">

                                        <div id="chartSelect" style="height: 370px; max-width: 920px; margin: 0px auto;">
                                        </div>

                                    </div>
                                </div>
                                <div class="col-lg-12 col-md-6 col-sm-6 col-xs-6 pl-0">
                                    <div class="banner-img">
                                        <!-- <img src="<?php echo base_url();?>/assets-panel/img/banner/4.png" alt=""> -->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
                        
        </div>

   
</section>

<?php echo $this->endsection();?>

<?php echo $this->section('jslibraies')?>
<script src="<?php echo base_url();?>/assets-panel/bundles/apexcharts/apexcharts.min.js"></script>
<script src="<?php echo base_url();?>/assets-panel/js/modules/dashboard/index.js"></script>
<script src="<?php echo base_url();?>/assets-panel/bundles/datatables/datatables.min.js"></script>
<script src="<?php echo base_url();?>/assets-panel/bundles/datatables/DataTables-1.10.16/js/dataTables.bootstrap4.min.js">
</script>
<script src="<?php echo base_url();?>/assets-panel/bundles/jquery-ui/jquery-ui.min.js"></script>
<script src="<?php echo base_url();?>/assets-panel/bundles/sweetalert/sweetalert.min.js"></script>
<!-- Add New Javascript -->
<script>
    function convertToRupiah(angka) {
    var rupiah = '';
    var angkarev = angka.toString().split('').reverse().join('');
    for (var i = 0; i < angkarev.length; i++)
        if (i % 3 == 0) rupiah += angkarev.substr(i, 3) + '.';
    return rupiah.split('', rupiah.length - 1).reverse().join('');
}




//CountOS
    axios.get(`<?php echo base_url();?>/api/dashboard/countOs`).then(
        res => {
            const {
                data
            } = res.data;
            data.forEach(item => {
                console.log('count');
                console.log(item.os);

                var count = document.getElementById('countOs');
                count.textContent = 'Rp ' + convertToRupiah(item.os) ;

                var noa = document.getElementById('noaOs');
                noa.textContent =  ' ' + convertToRupiah(item.noa) + ' ';

            })
        }).catch(err => {
        console.log(err)
    })

    //CountDPD
    axios.get(`<?php echo base_url();?>/api/dashboard/countDpd`).then(
        res => {
            const {
                data
            } = res.data;
            data.forEach(item => {
                console.log('count');
                console.log(item.os);

                var count = document.getElementById('countDpd');
                count.textContent = 'Rp ' + convertToRupiah(item.os);

                var noa = document.getElementById('noaDpd');
                noa.textContent =  '  ' + convertToRupiah(item.noa) + ' ';

            })
        }).catch(err => {
        console.log(err)
    })

    //CountDeviasi
    axios.get(`<?php echo base_url();?>/api/dashboard/countDeviasi`).then(
        res => {
            const {
                data
            } = res.data;
            console.log('oneobligorog', res.data.data);
            

                var count = document.getElementById('countDeviasi');
                count.textContent = convertToRupiah(res.data.data) + ' (x)';

                
        }).catch(err => {
        console.log(err)
    })

    //CountOneobligor
    axios.get(`<?php echo base_url();?>/api/dashboard/countOneobligor`).then(
        res => {
            const {
                data
            } = res.data;
            console.log('oneobligorog', res.data.data);
            

                var count = document.getElementById('countOneobligor');
                count.textContent = convertToRupiah(res.data.data) + ' (Nasabah)';

                
        }).catch(err => {
        console.log(err)
    })

    //CountLtv
    axios.get(`<?php echo base_url();?>/api/dashboard/countLtv`).then(
        res => {
            const {
                data
            } = res.data;
            data.forEach(item => {
                console.log('count');
                console.log(item.os);

                var count = document.getElementById('countLtv');
                count.textContent = convertToRupiah(item.noa) + '(x)';

                
            })
        }).catch(err => {
        console.log(err)
    })

    //CountBatal
    axios.get(`<?php echo base_url();?>/api/dashboard/countBatal`).then(
        res => {
            const {
                data
            } = res.data;
            data.forEach(item => {
                console.log('count');
                console.log(item.os);

                var count = document.getElementById('countBatal');
                count.textContent = convertToRupiah(item.noa) + '(x)';

                
            })
        }).catch(err => {
        console.log(err)
    })

    // //CountBatal
    // axios.get(`<?php echo base_url();?>/api/dashboard/batalAll`).then(
    //     res => {
    //         const {
    //             data
    //         } = res.data;
    //         data.forEach(item => {
    //             console.log('count');
    //             console.log(item.os);

    //             var count = document.getElementById('countBatal');
    //             count.textContent = convertToRupiah(item.noa) + '(x)';

                
    //         })
    //     }).catch(err => {
    //     console.log(err)
    // })

    // getOs();

    //Grafik

          var months = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September',
              'Oktober',
              'November', 'Desember'
          ];
        
     // OutstandingAll
    axios.get(`<?php echo base_url();?>/api/dashboard/outstandingAll`).then(
        res => {
            const {
                data
            } = res.data;
           

            const awal = [];

            
            data.forEach(item => {
               
                const a = awal.findIndex(f => {
                    return f.name == 'LTV';
                });


                const templateAwal = a > -1 ? awal[a] : {
                    
                    type: "spline",
                    yValueFormatString: "#,### ",
                    xValueFormatString: "MMM",
                    name: "LTV",
                    dataPoints: []
                }

                templateAwal.dataPoints.push({
                    label: months[item.month-1],
                    y: +item.os
                });

                if (a > -1) {
                    awal[a] = templateAwal;
                } else {
                    awal.push(templateAwal);
                }
            });


            var chart = new CanvasJS.Chart("chartOutstandingAll", {
                exportEnabled: true,
                animationEnabled: true,
                title: {
                    text: "Outstanding",
                    fontFamily: "arial black",
                    fontColor: "#695A42"
                },
                axisY: {
                    title: "Jumlah",
                    lineColor: "#4F81BC",
                    tickColor: "#4F81BC",
                    labelFontColor: "#4F81BC"
                },
               

                data: [...awal, ]
            });


            chart.render();
        }).catch(err => {
        console.log(err)
    })

     // DPD
    axios.get(`<?php echo base_url();?>/api/dashboard/dpdAll`).then(
        res => {
            const {
                data
            } = res.data;
           

            const awal = [];

            
            data.forEach(item => {
               
                const a = awal.findIndex(f => {
                    return f.name == 'DPD';
                });


                const templateAwal = a > -1 ? awal[a] : {
                    
                    type: "line",
                    yValueFormatString: "#,### ",
                    xValueFormatString: "MMM",
                    name: "DPD",

                    // showInLegend: true,
                    // markerType: "square",
                    color: "#F08080",
                    dataPoints: []
                }

                templateAwal.dataPoints.push({
                    label: months[item.month-1],
                    y: +item.os
                });

                if (a > -1) {
                    awal[a] = templateAwal;
                } else {
                    awal.push(templateAwal);
                }
            });


            var chart = new CanvasJS.Chart("chartDpd", {
                exportEnabled: true,
                animationEnabled: true,
                theme: "light2",
                title: {
                    text: "DPD",
                    fontFamily: "arial black",
                    fontColor: "#695A42"
                },
                axisY: {
                    title: "Jumlah",
                    lineColor: "#4F81BC",
                    tickColor: "#4F81BC",
                    labelFontColor: "#4F81BC",
                    crosshair: {
                        enabled: true
                    }
                },
                toolTip:{
                    shared:true
                },  
                // legend:{
                //     cursor:"pointer",
                //     verticalAlign: "bottom",
                //     horizontalAlign: "left",
                //     dockInsidePlotArea: true,
                //     itemclick: toogleDataSeries
                // },
               

                data: [...awal, ]
            });


            chart.render();
        }).catch(err => {
        console.log(err)
    })

     // Deviasi
    axios.get(`<?php echo base_url();?>/api/dashboard/deviasiAll`).then(
        res => {
            const {
                data
            } = res.data;
           

            const awal = [];

            
            data.forEach(item => {
               
                const a = awal.findIndex(f => {
                    return f.name == 'LTV';
                });


                const templateAwal = a > -1 ? awal[a] : {
                    
                    type: "line",
                    yValueFormatString: "#,### trx",
                    xValueFormatString: "MMM",
                    name: "LTV",
                    // color: "DarkGreen",

                    dataPoints: []
                }

                templateAwal.dataPoints.push({
                    label: months[item.month-1],
                    y: +item.noa
                });

                if (a > -1) {
                    awal[a] = templateAwal;
                } else {
                    awal.push(templateAwal);
                }
            });


            var chart = new CanvasJS.Chart("chartDeviasi", {
                exportEnabled: true,
                animationEnabled: true,
                theme: "light2",
                title: {
                    text: "Deviasi",
                    fontFamily: "arial black",
                    fontColor: "#695A42"
                },
                axisY: {
                    title: "Jumlah",
                    lineColor: "#4F81BC",
                    tickColor: "#4F81BC",
                    labelFontColor: "#4F81BC"
                },
               

                data: [...awal, ]
            });


            chart.render();
        }).catch(err => {
        console.log(err)
    })

    // Oneobligor
    axios.get(`<?php echo base_url();?>/api/dashboard/oneobligorAll`).then(
        res => {
            const {
                data
            } = res.data;
           

            const awal = [];

            
            data.forEach(item => {
               
                const a = awal.findIndex(f => {
                    return f.name == 'LTV';
                });


                const templateAwal = a > -1 ? awal[a] : {
                    
                    type: "spline",
                    yValueFormatString: "#,### trx",
                    xValueFormatString: "MMM",
                    name: "LTV",
                    dataPoints: []
                }

                templateAwal.dataPoints.push({
                    label: months[item.month-1],
                    y: +item.noa
                });

                if (a > -1) {
                    awal[a] = templateAwal;
                } else {
                    awal.push(templateAwal);
                }
            });


            var chart = new CanvasJS.Chart("chartOneobligor", {
                exportEnabled: true,
                animationEnabled: true,
                title: {
                    text: "Oneobligor",
                    fontFamily: "arial black",
                    fontColor: "#695A42"
                },
                axisY: {
                    title: "Nasabah",
                    lineColor: "#4F81BC",
                    tickColor: "#4F81BC",
                    labelFontColor: "#4F81BC"
                },
               

                data: [...awal, ]
            });


            chart.render();
        }).catch(err => {
        console.log(err)
    })

     // LTV
    axios.get(`<?php echo base_url();?>/api/dashboard/ltvAll`).then(
        res => {
            const {
                data
            } = res.data;
           

            const awal = [];

            
            data.forEach(item => {
               
                const a = awal.findIndex(f => {
                    return f.name == 'LTV';
                });


                const templateAwal = a > -1 ? awal[a] : {
                    
                    type: "spline",
                    yValueFormatString: "#,### trx",
                    xValueFormatString: "MMM",
                    name: "LTV",
                    dataPoints: []
                }

                templateAwal.dataPoints.push({
                    label: months[item.month-1],
                    y: +item.noa
                });

                if (a > -1) {
                    awal[a] = templateAwal;
                } else {
                    awal.push(templateAwal);
                }
            });


            var chart = new CanvasJS.Chart("chartLtv", {
                exportEnabled: true,
                animationEnabled: true,
                title: {
                    text: "LTV ",
                    fontFamily: "arial black",
                    fontColor: "#695A42"
                },
                axisY: {
                    title: "Jumlah",
                    lineColor: "#4F81BC",
                    tickColor: "#4F81BC",
                    labelFontColor: "#4F81BC"
                },
               

                data: [...awal, ]
            });


            chart.render();
        }).catch(err => {
        console.log(err)
    })

    // Pembatalan
    axios.get(`<?php echo base_url();?>/api/dashboard/batalAll`).then(
        res => {
            const {
                data
            } = res.data;
           

            const awal = [];

            
            data.forEach(item => {
               
                const a = awal.findIndex(f => {
                    return f.name == 'Pembatalan';
                });


                const templateAwal = a > -1 ? awal[a] : {
                    
                    type: "spline",
                    yValueFormatString: "#,### trx",
                    xValueFormatString: "MMM",
                    name: "Pembatalan",
                    color: "#F08080",
                    dataPoints: []
                }

                templateAwal.dataPoints.push({
                    label: months[item.month-1],
                    y: +item.noa
                });

                if (a > -1) {
                    awal[a] = templateAwal;
                } else {
                    awal.push(templateAwal);
                }
            });


            var chart = new CanvasJS.Chart("chartSelect", {
                exportEnabled: true,
                animationEnabled: true,
                title: {
                    text: "Pembatalan ",
                    fontFamily: "arial black",
                    fontColor: "#695A42"
                },
                axisY: {
                    title: "Jumlah",
                    lineColor: "#4F81BC",
                    tickColor: "#4F81BC",
                    labelFontColor: "#4F81BC"
                },
               

                data: [...awal, ]
            });


            chart.render();
        }).catch(err => {
        console.log(err)
    })

    //Revenue
var options = {
  chart: {
    exportEnabled: true,
    height: 230,
    type: "line",
    shadow: {
      enabled: true,
      color: "#000",
      top: 18,
      left: 7,
      blur: 10,
      opacity: 1
    },
    toolbar: {
      show: false
    }
  },
  colors: ["#3dc7be", "#ffa117"],
  dataLabels: {
    enabled: true
  },
  stroke: {
    curve: "smooth"
  },
  series: [{
    name: "High - 2019",
    data: [5, 15, 14, 36, 32, 32]
  },
//   {
//     name: "Low - 2019",
//     data: [7, 11, 30, 18, 25, 13]
//   }
  ],
  grid: {
    borderColor: "#e7e7e7",
    row: {
      colors: ["#f3f3f3", "transparent"], // takes an array which will be repeated on columns
      opacity: 0.0
    }
  },
  markers: {
    size: 6
  },
  xaxis: {
    categories: ["Jan", "Feb", "Mar", "Apr", "May", "Jun"],

    labels: {
      style: {
        colors: "#9aa0ac"
      }
    }
  },
  yaxis: {
    title: {
      text: "Income"
    },
    labels: {
      style: {
        color: "#9aa0ac"
      }
    },
    min: 5,
    max: 40
  },
  legend: {
    position: "top",
    horizontalAlign: "right",
    floating: true,
    offsetY: -25,
    offsetX: -5
  }
};

var chart = new ApexCharts(document.querySelector("#revenue"), options);

chart.render();

</script>

<?php echo $this->endSection();?>