<?php namespace App\Controllers\Api;
use App\Controllers\Api\BaseApiController;
use App\Models\MonitoringOsView;
use App\Models\PawnTransactions;
use DateTime;

/**
* Class Users
* @package App\Controllers\Api
* @author Bagus Aditia Setiawan
* @contact 081214069289
* @copyright saeapplication.com
*/

class Dashboard extends BaseApiController
 {
   public function __construct()
    {
        $db =  \Config\Database::connect(); // default database group
        $this->dbtests      = \Config\Database::connect('tests');
		$this->dbaccounting = \Config\Database::connect('accounting');
		$this->units = new \App\Models\Units();
        $this->cabang = new \App\Models\Cabang();
		$this->pawnTransactions = new \App\Models\PawnTransactions();
        $this->saldo = new \App\Models\DailyCash();
        $this->outstanding = new \App\Models\MonitoringOs();
        $this->defrosting = new \App\Models\MonitoringDefrosting();
        $this->repayment = new \App\Models\MonitoringRepayment();
        $this->dpd = new \App\Models\MonitoringDpd();
        $this->OsView= new \App\Models\MonitoringOsView();
        
        

    }
    public $modelName = '\App\Models\Products';

    /**
    * @var array
    * column of name table database
    * name of param post
    */
    //    [
    //        'column'    => 'value'
    // ]

    public $fillSearch = [
        // 'title'            => 'title',
        // 'url'              => 'url',
        // 'embedded'         => 'embedded',
    ];

    /**
    * @var array
    * column of name table database
    * name of param post
    */
    //    [
    //        'column'    => 'value'
    // ]
    public $fillWhere = [
        // 'name'              => 'name',
    ];

    //    [
    //        'name' => [
    //        'label'  => 'Name',
    //        'rules'  => 'required',
    //        'errors' => [
    //        'required' => 'Required Name '
    // ]
    // ],
    public $validateInsert = [
        // 'title' => [
        //     'label'  => 'title',
        //     'rules'  => 'required',
        //     'errors' => [
        //         'required' => 'Judul harus di isi'
        // ]
        // ],
        // 'embedded' => [
        //     'label'  => 'embedded',
        //     'rules'  => 'required',
        //     'errors' => [
        //         'required' => 'Embedded harus di isi'
        // ]
        // ]
    ];

    public $validateUpdate = [
        // 'id' => [
        //     'label'  => 'id',
        //     'rules'  => 'required',
        //     'errors' => [
        //         'required' => 'Id harus di isi'
        // ]
        // ],
        // 'title' => [
        //     'label'  => 'title',
        //     'rules'  => 'required',
        //     'errors' => [
        //         'required' => 'title harus di isi'
        // ]
        // ],
        // 'embedded' => [
        //     'label'  => 'embedded',
        //     'rules'  => 'required',
        //     'errors' => [
        //         'required' => 'embedded harus di isi'
        // ]
        // ]
    ];

    /**
    * @var array
    * column of name table database
    * name of param post
    */
    //    [
    //        'column'    => 'value'
    // ]
    public $fillableInsert = [
        // 'title'              => 'title',
        // 'url'                => 'url',
        // 'embedded'           => 'embedded'
    ];

    /**
    * @var array
    * column of name table database
    * name of param post
    */
    //    [
    //        'column'    => 'value'
    // ]

    public $fillableIupdate = [
        // 'title'              => 'title',
        // 'url'                => 'url',
        // 'embedded'           => 'embedded'
    ];

    //    product
    public $content = 'Devicelog';

    public function index()
 {

        if ( $this->model ) {
            $sumScan = ( new \App\Models\Devicelog )->countAllResults();
            $buyback = ( new \App\Models\Buyback )->where( 'type', 'Buy Back' )->countAllResults();
            $excange = ( new \App\Models\Buyback )->where( 'type', 'Online Exchange' )->countAllResults();
            $data = [
                'sum_scan'  => $sumScan,
                'buyback'  => $buyback,
                'exchange'  => $excange,
                'visitor'  => $sumScan,
            ];
            return $this->sendResponse( $data, 200 );
        }
        return $this->sendResponse( 'Model Not Found', 400, 'Model Not Found '.$this->model );

    }
    //--------------------------------------------------------------------

    public  function getInsertView($user_id, $view_id){
        $check = $this->OsView->where('view_id', $view_id)->where('user_id', $user_id)->first();
			
			if($check){
				$news = new MonitoringOsView();
				$update = $news->update($check->id, [
                	'view_id'	=> $view_id,
					'user_id'	=> $user_id,
                    'updated_at'	=> date("Y-m-d H:i:s")
            ]);
			
			}else{	

				$news = new MonitoringOsView();
           		 $news->insert([
                	'view_id'	=> $view_id,
					'user_id'	=> $user_id
            	]);

				
			}
    }
    public function getOutstanding(){
        $month = date('m');
        $sumOs = $this->outstanding->select('areas.area as area, date, sum(noa) as noa, sum(os) as os ')
			// ->from('pawn_transactions ')
			->join('units', 'units.office_id = monitoring_os.office_id')
            ->join('areas', 'areas.id=units.id_area')
            ->where('MONTH(date)', $month)
            ->groupBy('areas.area')	
            ->groupBy('date')	
            // ->where('areas.id', 1)
            ->findAll();
            // var_dump($sumOs); exit;
            // $user=session('user')->id;    
            // var_dump('user :');  
            // var_dump($user); exit;
        
            return $this->sendResponse($sumOs, 200);
    }

    public function getOutstandingAll(){
        $month = date('m');
        $area='60c6bfa6e64d1e2428630213';
        $sumOs = $this->outstanding->select(' branch_id, date, sum(noa) as noa, sum(os) as os ')
			// ->from('pawn_transactions ')
			->join('units', 'units.office_id = monitoring_os.office_id')
            // ->join('branches', 'branches.areas.id=units.id_area')
            ->where('MONTH(date)', $month)
            ->where('area_id', $area)
            ->groupBy('branch_id')	
            ->groupBy('date')	
            // ->where('areas.id', 1)
            ->findAll();
          

return $this->sendResponse($sumOs, 200);
}

public function getOutstandingUnits(){
$month = date('m');
$branch='60c6bffde64d1e2428630281';
$sumOs = $this->outstanding->select(' units.office_name, date, sum(noa) as noa, sum(os) as os ')
// ->from('pawn_transactions ')
->join('units', 'units.office_id = monitoring_os.office_id')
// ->join('branches', 'branches.areas.id=units.id_area')
->where('MONTH(date)', $month)
->where('units.branch_id', $branch)
->groupBy('units.office_name')
->groupBy('date')
// ->where('areas.id', 1)
->findAll();
// var_dump($sumOs); exit;

return $this->sendResponse($sumOs, 200);
}

public function getOutstandingSelectArea($area){

$month = date('m');
$sumOs = $this->outstanding->select(' cabang, date, sum(noa) as noa, sum(os) as os ')
// ->from('pawn_transactions ')
->join('units', 'units.office_id = monitoring_os.office_id')
->join('areas', 'areas.id=units.id_area')
->join('cabang', 'cabang.id=units.id_cabang')
->where('MONTH(date)', $month)
->where('areas.id', $area)
->groupBy('cabang.cabang')
->groupBy('date')
->findAll();
// var_dump($sumOs); exit;

return $this->sendResponse($sumOs, 200);
}

public function getOutstandingSelect($area,$branch){

$month = date('m');
$sumOs = $this->outstanding->select(' units.office_name, date, sum(noa) as noa, sum(os) as os ')
// ->from('pawn_transactions ')
->join('units', 'units.office_id = monitoring_os.office_id')
->join('areas', 'areas.id=units.id_area')
->join('cabang', 'cabang.id=units.id_cabang')
->where('MONTH(date)', $month)
->where('areas.id', $area)
->where('cabang.id', $branch)
->groupBy('units.office_name')
->groupBy('date')
// ->where('areas.id', 1)
->findAll();
// var_dump($sumOs); exit;

return $this->sendResponse($sumOs, 200);
}

public function getOutstandingSelectUnits($units){

$month = date('m');
$sumOs = $this->outstanding->select(' units.office_name, date, noa, os, noa_regular, regular, noa_instalment,
instalment, noa_opsi, opsi, noa_hp, hp ')
->join('units', 'units.office_id = monitoring_os.office_id')
->where('MONTH(date)', $month)
->where('units.id', $units)
->groupBy('units.office_name')
->groupBy('date')
->findAll();
// var_dump($sumOs); exit;

return $this->sendResponse($sumOs, 200);
}

public function getPencairan(){
$month = date('m');
$sumOs = $this->defrosting->select('areas.area as area, date, sum(noa) as noa, sum(os) as os ')
// ->from('pawn_transactions ')
->join('units', 'units.office_id = monitoring_defrosting.office_id')
->join('areas', 'areas.id=units.id_area')
->where('MONTH(date)', $month)
->groupBy('areas.area')
->groupBy('date')
// ->where('areas.id', 1)
->findAll();
// var_dump($sumOs); exit;

return $this->sendResponse($sumOs, 200);
}


public function getPencairanArea($area){
$month = date('m');
$sumOs = $this->defrosting->select('cabang, date, sum(noa) as noa, sum(os) as os ')
// ->from('pawn_transactions ')
->join('units', 'units.office_id = monitoring_defrosting.office_id')
->join('areas', 'areas.id=units.id_area')
->join('cabang', 'cabang.id=units.id_cabang')
->where('MONTH(date)', $month)
->where('areas.id', $area)
->groupBy('cabang.cabang')
->groupBy('date')
// ->where('areas.id', 1)
->findAll();
// var_dump($sumOs); exit;

return $this->sendResponse($sumOs, 200);
}

public function getPencairanCabang($area,$branch){
$month = date('m');
$sumOs = $this->defrosting->select('units.office_name, date, sum(noa) as noa, sum(os) as os ')
// ->from('pawn_transactions ')
->join('units', 'units.office_id = monitoring_defrosting.office_id')
->join('areas', 'areas.id=units.id_area')
->join('cabang', 'cabang.id=units.id_cabang')
->where('MONTH(date)', $month)
->where('areas.id', $area)
->where('cabang.id', $branch)
->groupBy('units.office_name')
->groupBy('date')
// ->where('areas.id', 1)
->findAll();
// var_dump('data');
// var_dump($sumOs); exit;

return $this->sendResponse($sumOs, 200);
}

public function getPencairanSelectUnits($units){
$month = date('m');
$sumOs = $this->defrosting->select('units.office_name, date, noa, os, noa_regular, regular, noa_instalment,
instalment, noa_opsi, opsi, noa_hp, hp ')
->join('units', 'units.office_id = monitoring_defrosting.office_id')
->where('MONTH(date)', $month)
->where('units.id', $units)
->groupBy('units.office_name')
->groupBy('date')
// ->where('areas.id', 1)
->findAll();
// var_dump('data');
// var_dump($sumOs); exit;

return $this->sendResponse($sumOs, 200);
}

public function getRepayment(){
$month = date('m');
$sumOs = $this->repayment->select('areas.area as area, date, sum(noa) as noa, sum(os) as os ')
// ->from('pawn_transactions ')
->join('units', 'units.office_id = monitoring_repayment.office_id')
->join('areas', 'areas.id=units.id_area')
->where('MONTH(date)', $month)
->groupBy('areas.area')
->groupBy('date')
// ->where('areas.id', 1)
->findAll();
// var_dump($sumOs); exit;

return $this->sendResponse($sumOs, 200);
}

public function getRepaymentArea($area){
$month = date('m');
$sumOs = $this->repayment->select('cabang, date, sum(noa) as noa, sum(os) as os ')
// ->from('pawn_transactions ')
->join('units', 'units.office_id = monitoring_repayment.office_id')
->join('areas', 'areas.id=units.id_area')
->join('cabang', 'cabang.id=units.id_cabang')
->where('MONTH(date)', $month)
->where('areas.id', $area)
->groupBy('cabang.cabang')
->groupBy('date')
// ->where('areas.id', 1)
->findAll();
// var_dump($sumOs); exit;

return $this->sendResponse($sumOs, 200);
}

public function getRepaymentCabang($area,$branch){
$month = date('m');
$sumOs = $this->repayment->select('units.office_name, date, sum(noa) as noa, sum(os) as os ')
// ->from('pawn_transactions ')
->join('units', 'units.office_id = monitoring_repayment.office_id')
->join('areas', 'areas.id=units.id_area')
->join('cabang', 'cabang.id=units.id_cabang')
->where('MONTH(date)', $month)
->where('areas.id', $area)
->where('cabang.id', $branch)
->groupBy('units.office_name')
->groupBy('date')
// ->where('areas.id', 1)
->findAll();
// var_dump($sumOs); exit;

return $this->sendResponse($sumOs, 200);
}

public function getRepaymentSelectUnits($units){
$month = date('m');
$sumOs = $this->repayment->select('units.office_name, date, noa, os, noa_regular, regular, noa_instalment,
instalment, noa_opsi, opsi, noa_hp, hp')
->join('units', 'units.office_id = monitoring_repayment.office_id')
->where('MONTH(date)', $month)
->where('units.id', $units)
->groupBy('units.office_name')
->groupBy('date')
// ->where('areas.id', 1)
->findAll();
// var_dump($sumOs); exit;

return $this->sendResponse($sumOs, 200);
}

public function getSaldo(){

$month = date('m');
$data = [];
$units = $this->units->select('area_id,office_id, office_name')->findAll();
foreach($units as $unit){

$sumOs = $this->saldo->select('areas.area as area, date, sum(noa) as noa, sum(os) as os ')
// ->from('pawn_transactions ')
->join('units', 'units.office_id = monitoring_repayment.office_id')
->join('areas', 'areas.id=units.id_area')
->where('MONTH(date)', $month)
->groupBy('areas.area')
->groupBy('date')
// ->where('areas.id', 1)
->findAll();
// var_dump($sumOs); exit;

}

return $this->sendResponse($sumOs, 200);
}

public function getDpd(){
$month = date('m');
$sumOs = $this->dpd->select('areas.area as area, date, sum(noa) as noa, sum(os) as os ')
// ->from('pawn_transactions ')
->join('units', 'units.office_id = monitoring_dpd.office_id')
->join('areas', 'areas.id=units.id_area')
->where('MONTH(date)', $month)
->groupBy('areas.area')
->groupBy('date')
// ->where('areas.id', 1)
->findAll();
// var_dump($sumOs); exit;

return $this->sendResponse($sumOs, 200);
}

public function getDpdArea($area){
$month = date('m');
$sumOs = $this->dpd->select(' cabang, date, sum(noa) as noa, sum(os) as os ')
// ->from('pawn_transactions ')
->join('units', 'units.office_id = monitoring_dpd.office_id')
->join('areas', 'areas.id=units.id_area')
->join('cabang', 'cabang.id=units.id_cabang')
->where('MONTH(date)', $month)
->where('areas.id', $area)
->groupBy('cabang.cabang')
->groupBy('date')
// ->where('areas.id', 1)
->findAll();
// var_dump($sumOs); exit;

return $this->sendResponse($sumOs, 200);
}
public function getDpdCabang($area,$branch){
$month = date('m');
$sumOs = $this->dpd->select('units.office_name, date, sum(noa) as noa, sum(os) as os ')
->join('units', 'units.office_id = monitoring_dpd.office_id')
->join('areas', 'areas.id=units.id_area')
->join('cabang', 'cabang.id=units.id_cabang')
->where('MONTH(date)', $month)
->where('areas.id', $area)
->where('cabang.id', $branch)
->groupBy('units.office_name')
->groupBy('date')
// ->where('areas.id', 1)
->findAll();
// var_dump($sumOs); exit;

return $this->sendResponse($sumOs, 200);
}

function getCabang($area){

$data = $this->cabang->select('id, cabang')->where('id_area', $area)->findAll();
return $this->sendResponse($data, 200);

}

function getUnits($branch){

$data = $this->units->select('id, name')->where('id_cabang', $branch)->findAll();
return $this->sendResponse($data, 200);

}

function getCountView($view_id){
    $data = $this->OsView->select('count(id) as count')->where('view_id', $view_id)->findAll();
return $this->sendResponse($data, 200);
}


}