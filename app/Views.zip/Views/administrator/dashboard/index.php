<?php echo $this->extend('layouts/administrator');?>

<?php echo $this->section('content');?>

<section class="section">

    <div class="row">

        <div class="col-xl-12 col-lg-6 col-md-6 col-sm-6 col-xs-12">
            <div class="card card-danger">
                <div class="card-header">
                    <div class="col-lg-3">
                        <select class="form-control" name="area_id" id="area_id">
                            <option value="">Select Area</option>
                            <?php foreach($areas as $area){ ?>
                            <option value="<?php echo $area->id; ?>"><?php echo $area->area; ?></option>
                            </option>
                            <?php  } ?>
                        </select>
                    </div>
                    <div class="col-lg-3">
                        <select class="form-control" name="branch_id" id="branch_id">
                            <option value="0">Select Cabang</option>
                        </select>
                        <input type="hidden" name="user_id" id="user_id" value="<?php echo session('user')->id ?>" />

                    </div>
                    <div class="col-lg-3">
                        <select class="form-control" name="units_id" id="units_id" onchange="getOutstanding()">
                            <option value="0">Select Units</option>
                        </select>

                    </div>
                    <div class="card-header-action">



                        <div id="count" class="dropdown dropdown-list-toggle">
                            <a href="#" data-toggle="dropdown" class="nav-link nav-link-lg message-toggle"><i
                                    data-feather="eye"></i>
                                <!-- <span id="count" class="badge headerBadge1">
                                    6 </span> -->
                            </a>
                            <div class="dropdown-menu dropdown-list dropdown-menu-right pullDown">
                                <div class="dropdown-header">
                                    Dilihat Oleh:
                                    <div class="float-right">
                                        <!-- <a href="#">Dilihat oleh :</a> -->
                                    </div>
                                </div>
                                <div class="dropdown-list-content dropdown-list-message">

                                    <?php foreach($view as $views){ 
                                        
                                //         $awal  = $views->updated_at;
                                // $akhir = now(); // waktu sekarang
                                // $diff  = date_diff( $awal, $akhir );
                                ?>
                                    <a href="#" class="dropdown-item"> <span class="dropdown-item-desc"> <span
                                                class="message-user"><?php echo $views->username; ?></span>
                                            <!-- <span class="time messege-text">Please check your mail !!</span> -->
                                            <span class="time">
                                                <?php //echo $diff->d;?> hari yang lalu
                                            </span>
                                        </span>
                                    </a>
                                    <?php } ?>
                                </div>
                                <div class="dropdown-footer text-center">
                                    <a href="#">View All <i class="fas fa-chevron-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


        </div>

        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-xs-12">
            <div class="card">
                <div class="card-statistic-4">
                    <div class="align-items-center justify-content-between">
                        <div class="row ">
                            <div class="col-lg-12 col-md- col-sm-6 col-xs-6 pr-0 pt-3">
                                <div class="card-content">


                                    <div id="chartNoa" style="height: 370px; max-width: 920px; margin: 0px auto;">
                                    </div>

                                </div>
                            </div>
                            <div class="col-lg-12 col-md-6 col-sm-6 col-xs-6 pl-0">
                                <div class="banner-img">
                                    <!-- <img src="<?php echo base_url();?>/assets-panel/img/banner/4.png" alt=""> -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-xs-12">
            <div class="card">
                <div class="card-statistic-4">
                    <div class="align-items-center justify-content-between">
                        <div class="row ">
                            <div class="col-lg-12 col-md- col-sm-6 col-xs-6 pr-0 pt-3">
                                <div class="card-content">
                                    <!-- <h5 class="font-15">Dashboard Outstanding Nasional</h5> -->
                                    <div id="chartOs" style="height: 370px; max-width: 920px; margin: 0px auto;">
                                    </div>

                                </div>
                            </div>
                            <div class="col-lg-12 col-md-6 col-sm-6 col-xs-6 pl-0">
                                <div class="banner-img">
                                    <!-- <img src="<?php echo base_url();?>/assets-panel/img/banner/4.png" alt=""> -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-xs-12">
            <div class="card">
                <div class="card-statistic-4">
                    <div class="align-items-center justify-content-between">

                        <div class="row ">

                            <div class="col-lg-12 col-md- col-sm-6 col-xs-6 pr-0 pt-3">

                                <div class="card-content">

                                    <div id="chartSelectAreaNoa"
                                        style="height: 370px; max-width: 920px; margin: 0px auto;">
                                    </div>

                                </div>
                            </div>
                            <div class="col-lg-12 col-md-6 col-sm-6 col-xs-6 pl-0">
                                <div class="banner-img">
                                    <!-- <img src="<?php echo base_url();?>/assets-panel/img/banner/4.png" alt=""> -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-xs-12">
            <div class="card">
                <div class="card-statistic-4">
                    <div class="align-items-center justify-content-between">

                        <div class="row ">

                            <div class="col-lg-12 col-md- col-sm-6 col-xs-6 pr-0 pt-3">

                                <div class="card-content">

                                    <div id="chartSelectArea"
                                        style="height: 370px; max-width: 920px; margin: 0px auto;">
                                    </div>

                                </div>
                            </div>
                            <div class="col-lg-12 col-md-6 col-sm-6 col-xs-6 pl-0">
                                <div class="banner-img">
                                    <!-- <img src="<?php echo base_url();?>/assets-panel/img/banner/4.png" alt=""> -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-xs-12">
            <div class="card">
                <div class="card-statistic-4">
                    <div class="align-items-center justify-content-between">
                        <div class="row ">

                            <div class="col-lg-12 col-md- col-sm-6 col-xs-6 pr-0 pt-3">
                                <div class="card-content">

                                    <div id="chartSelectNoa" style="height: 370px; max-width: 920px; margin: 0px auto;">
                                    </div>

                                </div>
                            </div>
                            <div class="col-lg-12 col-md-6 col-sm-6 col-xs-6 pl-0">
                                <div class="banner-img">
                                    <!-- <img src="<?php echo base_url();?>/assets-panel/img/banner/4.png" alt=""> -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-xs-12">
            <div class="card">
                <div class="card-statistic-4">
                    <div class="align-items-center justify-content-between">
                        <div class="row ">

                            <div class="col-lg-12 col-md- col-sm-6 col-xs-6 pr-0 pt-3">
                                <div class="card-content">

                                    <div id="chartSelect" style="height: 370px; max-width: 920px; margin: 0px auto;">
                                    </div>

                                </div>
                            </div>
                            <div class="col-lg-12 col-md-6 col-sm-6 col-xs-6 pl-0">
                                <div class="banner-img">
                                    <!-- <img src="<?php echo base_url();?>/assets-panel/img/banner/4.png" alt=""> -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-12 col-lg-6 col-md-6 col-sm-6 col-xs-12">
            <div class="card">
                <div class="card-statistic-4">
                    <div class="align-items-center justify-content-between">
                        <div class="row ">
                            <div class="col-lg-12 col-md- col-sm-6 col-xs-6 pr-0 pt-3">
                                <div class="card-content">
                                    <div id="chartUnits" style="height: 370px; max-width: 920px; margin: 0px auto;">
                                    </div>
                                </div>

                            </div>
                        </div>
                        <div class="col-lg-12 col-md-6 col-sm-6 col-xs-6 pl-0">
                            <div class="banner-img">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
    </div>

    <input type="hidden" name="url_get_cabang" id="url_get_cabang"
        value="<?php echo base_url('generate/office/getCabang') ?>" />
    <input type="hidden" name="url_get_units" id="url_get_units"
        value="<?php echo base_url('api/datamaster/units/get_unit_bycabang') ?>" />

</section>

<?php echo $this->endsection();?>

<?php echo $this->section('jslibraies')?>
<script src="<?php echo base_url();?>/assets-panel/bundles/apexcharts/apexcharts.min.js"></script>
<script src="<?php echo base_url();?>/assets-panel/js/modules/dashboard/index.js"></script>
<script src="<?php echo base_url();?>/assets-panel/bundles/datatables/datatables.min.js"></script>
<script
    src="<?php echo base_url();?>/assets-panel/bundles/datatables/DataTables-1.10.16/js/dataTables.bootstrap4.min.js">
</script>
<script src="<?php echo base_url();?>/assets-panel/bundles/jquery-ui/jquery-ui.min.js"></script>
<script src="<?php echo base_url();?>/assets-panel/bundles/sweetalert/sweetalert.min.js"></script>

<!-- Add New Javascript -->
<script>
$('[name="area_id"]').on('change', function() {
    var area = $(this).val();
    var branch = document.getElementById('branch_id');
    let array = [];
    // var url_data = $('#url_get_cabang').val() + '/' + area;
    axios.get(`<?php echo base_url();?>/api/dashboard/getCabang/${area}`).then(
        res => {
            const {
                data
            } = res.data;
            console.log('test');
            // console.log(build);
            data.forEach(item => {

                var opt = document.createElement("option");
                opt.value = item.id;
                opt.text = item.cabang;
                branch.appendChild(opt);


            })
        });
});

$('[name="branch_id"]').on('change', function() {
    var branch = $(this).val();
    var units = document.getElementById('units_id');
    let array = [];
    // var url_data = $('#url_get_c').val() + '/' + area;
    axios.get(`<?php echo base_url();?>/api/dashboard/getUnits/${branch}`).then(
        res => {
            const {
                data
            } = res.data;
            console.log('test');
            // console.log(build);
            data.forEach(item => {

                var opt = document.createElement("option");
                opt.value = item.id;
                opt.text = item.name;
                units.appendChild(opt);


            })
        });
});
</script>
<script>
function convertToRupiah(angka) {
    var rupiah = '';
    var angkarev = angka.toString().split('').reverse().join('');
    for (var i = 0; i < angkarev.length; i++)
        if (i % 3 == 0) rupiah += angkarev.substr(i, 3) + '.';
    return rupiah.split('', rupiah.length - 1).reverse().join('');
}

var getOutstanding;

window.onload = function() {
    var count = document.getElementById('count');
    var view_id = 1;
    axios.get(`<?php echo base_url();?>/api/dashboard/getCountView/${view_id}`).then(
        res => {
            const {
                data
            } = res.data;
            data.forEach(item => {
                console.log('count');
                console.log(item.count);

                var closeSpan = document.createElement("span");
                closeSpan.setAttribute("class", "badge headerBadge1");
                closeSpan.textContent = item.count;

                // var opt = document.createElement("span");
                // // opt.value = item.id;
                // opt.text = item.count;
                // count.appendChild(opt);


            })
        }).catch(err => {
        console.log(err)
    })


    axios.get(`<?php echo base_url();?>/api/dashboard/getOutstanding`).then(res => {
        const {
            data
        } = res.data;
        const build = [];
        var total = 0;
        console.log(build)
        data.forEach(item => {
            total += parseInt(item.os);
            const index = build.findIndex(f => {
                return f.name == item.area;
            });
            console.log(index)
            const template = index > -1 ? build[index] : {
                type: 'spline',
                name: item.area,
                showInLegend: 'true',
                dataPoints: [],
            }
            template.dataPoints.push({
                label: item.date,
                y: +item.os
            });

            if (index > -1) {
                build[index] = template;
            } else {
                build.push(template)
            }
        })
        var chart = new CanvasJS.Chart("chartOs", {
            animationEnabled: true,
            exportEnabled: true,
            title: {
                text: "OS Nasional  "
            },
            axisY: {
                title: "Outstanding"
            },
            toolTip: {
                shared: true
            },
            legend: {
                cursor: "pointer",
                itemclick: toggleDataSeries
            },
            data: build,

        });

        chart.render();
    }).catch(err => {
        console.log(err)
    })



    function toggleDataSeries(e) {
        if (typeof(e.dataSeries.visible) === "undefined" || e.dataSeries.visible) {
            e.dataSeries.visible = false;
        } else {
            e.dataSeries.visible = true;
        }
        chart.render();
    }

    axios.get(`<?php echo base_url();?>/api/dashboard/getOutstanding`).then(res => {
        const {
            data
        } = res.data;
        const build = [];
        var total = 0;
        console.log(build)
        data.forEach(item => {
            total += parseInt(item.noa);
            const index = build.findIndex(f => {
                return f.name == item.area;
            });
            console.log(index);
            const template = index > -1 ? build[index] : {
                type: 'spline',
                name: item.area,
                showInLegend: 'true',
                dataPoints: [],
            }
            template.dataPoints.push({
                label: item.date,
                y: +item.noa
            });

            if (index > -1) {
                build[index] = template;
            } else {
                build.push(template)
            }
        })
        var chart = new CanvasJS.Chart("chartNoa", {
            animationEnabled: true,
            exportEnabled: true,
            title: {
                text: "Noa Outstanding Nasional "
            },
            axisY: {
                title: "Noa"
            },
            toolTip: {
                shared: true
            },
            legend: {
                cursor: "pointer",
                itemclick: toggleDataSeries
            },
            data: build,

        });

        chart.render();
    }).catch(err => {
        console.log(err)
    })



    function toggleDataSeries(e) {
        if (typeof(e.dataSeries.visible) === "undefined" || e.dataSeries.visible) {
            e.dataSeries.visible = false;
        } else {
            e.dataSeries.visible = true;
        }
        chart.render();
    }




}

function getOutstanding() {
    var user_id = $('#user_id').val();
    var view_id = 1;
    var selectArea = $('#area_id').val();
    var selectBox = $('#branch_id').val();
    var units = $('#units_id').val();

    console.log("selectBox");
    console.log(selectBox);

    axios.get(`<?php echo base_url();?>/api/dashboard/getInsertView/${user_id}/${view_id}`).then(
        res => {
            const {
                data
            } = res.data;
        }).catch(err => {
        console.log(err)
    })

    // AreaNoa
    axios.get(`<?php echo base_url();?>/api/dashboard/getOutstandingSelectArea/${selectArea}`).then(
        res => {
            const {
                data
            } = res.data;
            const build = [];
            console.log(res);
            console.log('build');
            console.log(build);
            data.forEach(item => {
                const index = build.findIndex(f => {
                    return f.name == item.cabang
                });
                console.log(index)
                const template = index > -1 ? build[index] : {
                    type: 'spline',
                    name: item.cabang,
                    showInLegend: 'true',
                    dataPoints: [],
                }
                template.dataPoints.push({
                    label: item.date,
                    y: +item.noa,
                });

                if (index > -1) {
                    build[index] = template;
                } else {
                    build.push(template)
                }
            })
            var chart = new CanvasJS.Chart("chartSelectAreaNoa", {
                animationEnabled: true,
                exportEnabled: true,
                title: {
                    text: "Noa Outstanding Area "
                },
                axisY: {
                    title: "Noa"
                },
                toolTip: {
                    shared: true
                },
                legend: {
                    cursor: "pointer",
                    itemclick: toggleDataSeries
                },
                data: build,

            });

            chart.render();
        }).catch(err => {
        console.log(err)
    })



    function toggleDataSeries(e) {
        if (typeof(e.dataSeries.visible) === "undefined" || e.dataSeries.visible) {
            e.dataSeries.visible = false;
        } else {
            e.dataSeries.visible = true;
        }
        chart.render();
    }
    // Area
    axios.get(`<?php echo base_url();?>/api/dashboard/getOutstandingSelectArea/${selectArea}`).then(
        res => {
            const {
                data
            } = res.data;
            const build = [];
            console.log(res);
            console.log('build');
            console.log(build);
            data.forEach(item => {
                const index = build.findIndex(f => {
                    return f.name == item.cabang
                });
                console.log(index)
                const template = index > -1 ? build[index] : {
                    type: 'spline',
                    name: item.cabang,
                    showInLegend: 'true',
                    dataPoints: [],
                }
                template.dataPoints.push({
                    label: item.date,
                    y: +item.os,
                });

                if (index > -1) {
                    build[index] = template;
                } else {
                    build.push(template)
                }
            })
            var chart = new CanvasJS.Chart("chartSelectArea", {
                animationEnabled: true,
                exportEnabled: true,
                title: {
                    text: "Outstanding Area"
                },
                axisY: {
                    title: "Outstanding"
                },
                toolTip: {
                    shared: true
                },
                legend: {
                    cursor: "pointer",
                    itemclick: toggleDataSeries
                },
                data: build,

            });

            chart.render();
        }).catch(err => {
        console.log(err)
    })



    function toggleDataSeries(e) {
        if (typeof(e.dataSeries.visible) === "undefined" || e.dataSeries.visible) {
            e.dataSeries.visible = false;
        } else {
            e.dataSeries.visible = true;
        }
        chart.render();
    }

    // UnitsNoa
    axios.get(`<?php echo base_url();?>/api/dashboard/getOutstandingSelect/${selectArea}/${selectBox}`)
        .then(res => {
            const {
                data
            } = res.data;
            const build = [];
            console.log(build);
            data.forEach(item => {
                const index = build.findIndex(f => {
                    return f.name == item.office_name
                });
                console.log(index)
                const template = index > -1 ? build[index] : {
                    type: 'spline',
                    name: item.office_name,
                    showInLegend: 'true',
                    dataPoints: [],
                }
                template.dataPoints.push({
                    label: item.date,
                    y: +item.noa,
                });

                if (index > -1) {
                    build[index] = template;
                } else {
                    build.push(template)
                }
            })
            var chart = new CanvasJS.Chart("chartSelectNoa", {
                animationEnabled: true,
                exportEnabled: true,
                title: {
                    text: "Noa Outstanding Cabang"
                },
                axisY: {
                    title: "Noa"
                },
                toolTip: {
                    shared: true
                },
                legend: {
                    cursor: "pointer",
                    itemclick: toggleDataSeries
                },
                data: build,

            });

            chart.render();
        }).catch(err => {
            console.log(err)
        })



    function toggleDataSeries(e) {
        if (typeof(e.dataSeries.visible) === "undefined" || e.dataSeries.visible) {
            e.dataSeries.visible = false;
        } else {
            e.dataSeries.visible = true;
        }
        chart.render();
    }
    // Units
    axios.get(`<?php echo base_url();?>/api/dashboard/getOutstandingSelect/${selectArea}/${selectBox}`)
        .then(res => {
            const {
                data
            } = res.data;
            const build = [];
            console.log(build);
            data.forEach(item => {
                const index = build.findIndex(f => {
                    return f.name == item.office_name
                });
                console.log(index)
                const template = index > -1 ? build[index] : {
                    type: 'spline',
                    name: item.office_name,
                    showInLegend: 'true',
                    dataPoints: [],
                }
                template.dataPoints.push({
                    label: item.date,
                    y: +item.os,
                });

                if (index > -1) {
                    build[index] = template;
                } else {
                    build.push(template)
                }
            })
            var chart = new CanvasJS.Chart("chartSelect", {
                animationEnabled: true,
                exportEnabled: true,
                title: {
                    text: "Outstanding Cabang "
                },
                axisY: {
                    title: "Outstanding"
                },
                toolTip: {
                    shared: true
                },
                legend: {
                    cursor: "pointer",
                    itemclick: toggleDataSeries
                },
                data: build,

            });

            chart.render();
        }).catch(err => {
            console.log(err)
        })



    function toggleDataSeries(e) {
        if (typeof(e.dataSeries.visible) === "undefined" || e.dataSeries.visible) {
            e.dataSeries.visible = false;
        } else {
            e.dataSeries.visible = true;
        }
        chart.render();
    }


    //os Reguler, opsi, smartphone
    axios.get(`<?php echo base_url();?>/api/dashboard/getOutstandingSelectUnits/${units}`).then(res => {
        const {
            data
        } = res.data;
        const build = [];
        const reguler = [];
        const hp = [];
        const instalment = [];
        const opsi = [];
        var unit = '';

        console.log('new instanceof instance');
        console.log(reguler);
        console.log(hp);
        console.log(opsi);
        console.log(instalment);
        data.forEach(item => {

            unit = item.office_name;
            const a = reguler.findIndex(f => {
                return f.name == 'Reguler';
            });
            const b = opsi.findIndex(f => {
                return f.name == 'Opsi';
            });
            const c = instalment.findIndex(f => {
                return f.name == 'Cicilan';
            });
            const d = hp.findIndex(f => {
                return f.name == 'Smartphone';
            });


            const reg = a > -1 ? reguler[a] : {
                type: "stackedColumn",
                showInLegend: true,
                color: "#B6B1A8",
                name: "Reguler",
                dataPoints: []
            }
            const ops = b > -1 ? opsi[b] : {
                type: "stackedColumn",
                showInLegend: true,
                color: "#EDCA93",

                name: "Opsi",
                dataPoints: []
            }
            const instal = c > -1 ? instalment[c] : {
                type: "stackedColumn",
                showInLegend: true,
                color: "#695A42",
                name: "Cicilan",
                dataPoints: []
            }
            const h = d > -1 ? hp[d] : {
                type: "stackedColumn",
                showInLegend: true,
                color: "#EDCA93",

                name: "Smartphone",
                dataPoints: []
            }
            console.log(reg);
            console.log(ops);
            console.log(instal);
            console.log(h);

            reg.dataPoints.push({
                x: new Date(item.date),
                y: +item.regular
            });
            ops.dataPoints.push({
                x: new Date(item.date),
                y: +item.opsi
            });
            instal.dataPoints.push({
                x: new Date(item.date),
                y: +item.instalment
            });
            h.dataPoints.push({
                x: item.date,
                y: +item.hp
            });

            if (a > -1) {
                reguler[a] = reg;
            } else {
                reguler.push(reg)
            }
            if (b > -1) {
                opsi[b] = ops;
            } else {
                opsi.push(ops)
            }
            if (c > -1) {
                instalment[c] = instal;
            } else {
                instalment.push(instal)
            }
            if (d > -1) {
                hp[d] = h;

            } else {
                hp.push(h)
            }
        })

        var chart = new CanvasJS.Chart("chartUnits", {
            exportEnabled: true,
            animationEnabled: true,
            title: {
                text: "Outstanding Unit " + unit,
                fontFamily: "arial black",
                fontColor: "#695A42"
            },
            axisX: {
                interval: 1,
                // intervalType: "year"
            },
            axisY: {
                // valueFormatString: "$#0bn",
                gridColor: "#B6B1A8",
                tickColor: "#B6B1A8"
            },
            toolTip: {
                shared: true,
                content: toolTipContent
            },
            data: [...reguler,
                ...opsi,
                ...instalment,
                ...hp,
            ]
        });
        console.log(reguler, opsi, hp);
        chart.render();
    }).catch(err => {
        console.log(err)
    })

    var months = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September',
        'Oktober',
        'November', 'Desember'
    ]

    function toolTipContent(e) {
        var str = "";
        var total = 0;
        var str2, str3;
        for (var i = 0; i < e.entries.length; i++) {
            var str1 = "<span style= 'color:" + e.entries[i].dataSeries.color + "'> " + e.entries[i]
                .dataSeries
                .name + "</span>: Rp <strong>" + e.entries[i].dataPoint.y + "</strong><br/>";
            total = e.entries[i].dataPoint.y + total;
            str = str.concat(str1);
        }
        str2 = `<span style = 'color:DodgerBlue;'><strong>" ${e.entries[0].dataPoint.x.getDate()} ${months[e.entries[0].dataPoint.x.getMonth()]} ${e.entries[0].dataPoint.x.getFullYear()} 
            "</strong></span><br/>`;
        total = Math.round(total * 100) / 100;
        str3 = "<span style = 'color:Tomato'>Total:</span><strong> Rp " + total + "</strong><br/>";
        return (str2.concat(str)).concat(str3);
    }
}
</script>


<?php echo $this->endSection();?>