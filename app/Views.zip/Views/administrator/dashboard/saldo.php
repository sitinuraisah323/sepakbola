<?php echo $this->extend('layouts/administrator');?>

<?php echo $this->section('content');?>

<section class="section">

    <div class="row ">

        <div class="col-xl-12 col-lg-6 col-md-6 col-sm-6 col-xs-12">
            <div class="card">
                <div class="card-statistic-4">
                    <div class="align-items-center justify-content-between">
                        <div class="row ">
                            <div class="col-lg-12 col-md- col-sm-6 col-xs-6 pr-0 pt-3">
                                <div class="card-content">
                                    <!-- <h5 class="font-15">Dashboard Outstanding Nasional</h5> -->
                                    <div id="chartNoa" style="height: 370px; max-width: 920px; margin: 0px auto;">
                                    </div>

                                </div>
                            </div>
                            <div class="col-lg-12 col-md-6 col-sm-6 col-xs-6 pl-0">
                                <div class="banner-img">
                                    <!-- <img src="<?php echo base_url();?>/assets-panel/img/banner/4.png" alt=""> -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-12 col-lg-6 col-md-6 col-sm-6 col-xs-12">
            <div class="card">
                <div class="card-statistic-4">
                    <div class="align-items-center justify-content-between">
                        <div class="row ">
                            <div class="col-lg-12 col-md- col-sm-6 col-xs-6 pr-0 pt-3">
                                <div class="card-content">
                                    <!-- <h5 class="font-15">Dashboard Outstanding Nasional</h5> -->
                                    <div id="chartOs" style="height: 370px; max-width: 920px; margin: 0px auto;">
                                    </div>

                                </div>
                            </div>
                            <div class="col-lg-12 col-md-6 col-sm-6 col-xs-6 pl-0">
                                <div class="banner-img">
                                    <!-- <img src="<?php echo base_url();?>/assets-panel/img/banner/4.png" alt=""> -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


</section>

<?php echo $this->endsection();?>

<?php echo $this->section('jslibraies')?>
<script src="<?php echo base_url();?>/assets-panel/bundles/apexcharts/apexcharts.min.js"></script>
<script src="<?php echo base_url();?>/assets-panel/js/modules/dashboard/index.js"></script>
<script src="<?php echo base_url();?>/assets-panel/bundles/datatables/datatables.min.js"></script>
<script
    src="<?php echo base_url();?>/assets-panel/bundles/datatables/DataTables-1.10.16/js/dataTables.bootstrap4.min.js">
</script>
<script src="<?php echo base_url();?>/assets-panel/bundles/jquery-ui/jquery-ui.min.js"></script>
<script src="<?php echo base_url();?>/assets-panel/bundles/sweetalert/sweetalert.min.js"></script>

<!-- Add New Javascript -->
<script>
// function chartOs() {
window.onload = function() {

    axios.get(`<?php echo base_url();?>/api/dashboard/getPencairan`).then(res => {
        const {
            data
        } = res.data;
        const build = [];
        console.log(build)
        data.forEach(item => {
            const index = build.findIndex(f => {
                return f.name == item.area;
            });
            console.log(index)
            const template = index > -1 ? build[index] : {
                type: 'spline',
                name: item.area,
                showInLegend: 'true',
                dataPoints: [],
            }
            template.dataPoints.push({
                label: item.date,
                y: +item.os
            });

            if (index > -1) {
                build[index] = template;
            } else {
                build.push(template)
            }
        })
        var chart = new CanvasJS.Chart("chartOs", {
            animationEnabled: true,
            exportEnabled: true,
            title: {
                text: "Dashboard Pencairan"
            },
            axisY: {
                title: "Outstanding"
            },
            toolTip: {
                shared: true
            },
            legend: {
                cursor: "pointer",
                itemclick: toggleDataSeries
            },
            data: build,

        });

        chart.render();
    }).catch(err => {
        console.log(err)
    })



    function toggleDataSeries(e) {
        if (typeof(e.dataSeries.visible) === "undefined" || e.dataSeries.visible) {
            e.dataSeries.visible = false;
        } else {
            e.dataSeries.visible = true;
        }
        chart.render();
    }

    axios.get(`<?php echo base_url();?>/api/dashboard/getPencairan`).then(res => {
        const {
            data
        } = res.data;
        const build = [];
        console.log(build)
        data.forEach(item => {
            const index = build.findIndex(f => {
                return f.name == item.area;
            });
            console.log(index)
            const template = index > -1 ? build[index] : {
                type: 'spline',
                name: item.area,
                showInLegend: 'true',
                dataPoints: [],
            }
            template.dataPoints.push({
                label: item.date,
                y: +item.noa
            });

            if (index > -1) {
                build[index] = template;
            } else {
                build.push(template)
            }
        })
        var chart = new CanvasJS.Chart("chartNoa", {
            animationEnabled: true,
            exportEnabled: true,
            title: {
                text: "Dashboard Noa Pencairan "
            },
            axisY: {
                title: "Noa"
            },
            toolTip: {
                shared: true
            },
            legend: {
                cursor: "pointer",
                itemclick: toggleDataSeries
            },
            data: build,

        });

        chart.render();
    }).catch(err => {
        console.log(err)
    })



    function toggleDataSeries(e) {
        if (typeof(e.dataSeries.visible) === "undefined" || e.dataSeries.visible) {
            e.dataSeries.visible = false;
        } else {
            e.dataSeries.visible = true;
        }
        chart.render();
    }

}
// }

// }

// jQuery(document).ready(function() {
//     chartNoa();
//     chartOs();

// });
</script>

<script>

</script>
<?php echo $this->endSection();?>