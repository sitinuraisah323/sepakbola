<?php 
namespace App\Controllers\Transactions;

use App\Middleware\Authenticated;
use App\Models\Area;
use App\Models\MonitoringOsView;

class Pencairan extends Authenticated
{
	public function __construct()
    {
        $this->db1 = db_connect(); // default database group
        $this->dbtests      = \Config\Database::connect('tests');
		$this->dbaccounting = \Config\Database::connect('accounting');
        // $this->db2 = db_connect("tests"); // other database group
		// $pawn = new pawn_transactionsModel();
    }
	public function index()
	{
		return view('transactions/index');
	}

	public function outstanding($date, $units)
	{
		$area = new Area();
		$view = new MonitoringOsView();
		$data['areas'] = $area->getArea();
		// $data['view'] = $view->getViewPelunasan();
		$data['date'] = $date;
		$data['units'] = $units;
		return view('transactions/detail/outstanding', $data);
	}

	public function pencairan($date, $units)
	{
		$area = new Area();
		$view = new MonitoringOsView();
		$data['areas'] = $area->getArea();
		$data['view'] = $view->getViewPencairan();
		$data['date'] = $date;
		$data['units'] = $units;
		return view('transactions/detail/pencairan', $data);
	}

	public function pelunasan($date, $units)
	{
		$area = new Area();
		$view = new MonitoringOsView();
		$data['areas'] = $area->getArea();
		// $data['view'] = $view->getViewPelunasan();
		$data['date'] = $date;
		$data['units'] = $units;
		return view('transactions/detail/repayment', $data);
	}

	public function perpanjangan($date, $units)
	{
		$area = new Area();
		$view = new MonitoringOsView();
		$data['areas'] = $area->getArea();
		// $data['view'] = $view->getViewPelunasan();
		$data['date'] = $date;
		$data['units'] = $units;
		return view('transactions/detail/perpanjangan', $data);
	}
}