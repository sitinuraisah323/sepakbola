<?php echo $this->extend('layouts/administrator');?>

<?php echo $this->section('content');?>

<section class="section">

    <div class="row ">

        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="card card-danger">
                <div class="card-header">
                    <div class="col-lg-3">
                        <select class="form-control" name="area_id" id="area_id">
                            <option value="0">Select Area</option>
                            <?php foreach($areas as $area){ ?>
                            <option value="<?php echo $area->area_id; ?>"><?php echo $area->area; ?></option>
                            </option>
                            <?php  } ?>
                        </select>
                    </div>
                    <div class="col-lg-3">
                        <select class="form-control" name="branch_id" id="branch_id">
                            <option value="0">Select Cabang</option>
                        </select>
                        <input type="hidden" name="user_id" id="user_id" value="<?php echo session('user')->id ?>" />

                    </div>
                    <div class="col-lg-3">
                        <select class="form-control" name="units_id" id="units_id">
                            <option value="0">Select Units</option>
                        </select>
                    </div>
                    <div class="col-lg-3" >
                        <select class="form-control" name="category" id="category">
                            <option value="0">Select Fraud</option>
                            <option value="A">LTV</option>
                            <option value="B">Outstanding</option>
                            <option value="C">Ticketsize</option>
                            <option value="D">Frequensi</option>
                            <option value="E">Saldo DPD</option>
                            <option value="F">Modal Kerja</option>
                            <option value="G">Saldo Kas</option>
                            <option value="H">Transaksi Batal</option>
                            <option value="I">Approval</option>
                            <option value="J">Oneobligor</option>
                        </select>

                    </div>
                </div>
                <div class="card-header">
                  <div id="selectTiering" class="col-lg-3" style=" display: none;">
                        <select class="form-control" name="tiering" id="tiering">
                            <option value="0">Select Category</option>
                            <option value="A">Up 10rb - 20jt</option>
                            <option value="B">Up 20,01jt - 50jt</option>
                            <option value="C">Up 50,01jt - 100jt</option>
                            <option value="D">Up 100,01jt - 150jt</option>
                            <option value="E">Up 150,01jt - 250jt</option>
                              <option value="F">Up 250,01 - 2M</option>
                        </select>

                    </div>

                <div id="selectFrequensi"  class="col-lg-3" style=" display: none;">
                  <div class="form-group">
                    <div class="input-group mb-3">
                      <div class="input-group-prepend">
                            <span class="form-control input-group-text">>=</span>
                      </div>
                        <input type="text" class="form-control text-right"  aria-label="Amount (to the nearest dollar)" id="frequensi" name="frequensi" value='5' placeholder="Angka Frequensi">
                      <div class="input-group-append">
                            <span class="form-control input-group-text">X</span>
                      </div>
                    </div>
                  </div>
                </div>


                <!-- <div id="selectStatus" class="col-lg-3" style=" display: none;">
                        <select class="form-control" name="status" id="status">
                            <option value="all">Select Status </option>
                            <option value="0"> Dibawah Pagukas </option>
                            <option value="1"> Diatas Pagukas </option>
                        </select>
                </div> -->

                <div id="selectStatus"  class="col-lg-3" style=" display: none;">
                  <div class="form-group">
                    <div class="input-group mb-2">
                      <div class="input-group-prepend">
                            <span class="form-control input-group-text">Rp</span>
                      </div>
                        <input type="text" class="form-control text-right"  aria-label="Amount (to the nearest dollar)" id="status" name="status" value='30.000.000' placeholder="Rupiah">
                      <!-- <div class="input-group-append">
                            <span class="form-control input-group-text"></span>
                      </div> -->
                    </div>
                  </div>
                </div>

                <div id="selectLimit"  class="col-lg-3" style=" display: none;">
                  <div class="form-group">
                    <div class="input-group mb-3">
                      <div class="input-group-prepend">
                            <span class="form-control input-group-text">>=</span>
                      </div>
                        <input type="text" class="form-control text-right"  aria-label="Amount (to the nearest dollar)" id="limit" name="limit" value='5' placeholder="Angka Persentase">
                      <div class="input-group-append">
                            <span class="form-control input-group-text">%</span>
                      </div>
                    </div>
                  </div>
                </div>

                    <div id="selectLimitRp" class="col-lg-3" style=" display: none;">
                        <select class="form-control" name="limitRp" id="limitRp">
                            <option value="0">Select Limit</option>
                            <option value="A"> 0 - 5jt </option>
                            <option value="B"> 5 - 10jt </option>
                            <option value="C"> > 10jt</option>
                            <!-- <option value="D"> > 92%</option>                             -->
                        </select>
                    </div>
                              
                    <div id="selectApproval" class="col-lg-3" style=" display: none;">
                        <select class="form-control" name="approval" id="approval">
    
                            <option value="all">All Approval</option>
                            <option value="0">Cabang</option>
                            <option value="1">Area</option>								
                            <option value="2">Regional</option>
                            <option value="3">Pusat</option>                                            
                        </select>
                    </div>

                    <div id="selectDeviasi"  class="col-lg-3" style=" display: none;">
                        <select class="form-control" name="deviasi" id="deviasi">
                            <option value="all">All Deviasi</option>
                            <option value="0">LTV</option>
                            <option value="1">Sewa</option>								
                            <option value="2">Admin</option>
                            <option value="3">One Obligor</option>
                            <option value="5">Limit Transaksi</option>
                        </select>

                    </div>
                    <div class="col-lg-3">
                        <input type="date" class="form-control" name="dateStart" id="dateStart" value="<?php echo date('Y-m-01') ?>" />
                    </div>
                    <div class="col-lg-3">
                        <input type="date" class="form-control" name="dateEnd" id="dateEnd" value="<?php echo date('Y-m-d') ?>" />
                    </div>

                    <!-- <div class="card-header-action">
                        <div id="count" class="dropdown dropdown-list-toggle">
                            <a href="#" data-toggle="dropdown" class="nav-link nav-link-lg message-toggle"><i
                                    data-feather="eye"></i>
                               
                            </a>
                            <div class="dropdown-menu dropdown-list dropdown-menu-right pullDown">
                                <div class="dropdown-header">
                                    Dilihat Oleh:
                                    <div class="float-right">
                                    </div>
                                </div>
                                <div class="dropdown-list-content dropdown-list-message">

                                    <?php foreach($view as $views){ 
                                        
                                ?>
                                    <a href="#" class="dropdown-item"> <span class="dropdown-item-desc"> <span
                                                class="message-user"><?php echo $views->username; ?></span>
                                            <span class="time">
                                                <?php //echo $diff->d;?> hari yang lalu
                                            </span>
                                        </span>
                                    </a>
                                    <?php } ?>
                                </div>
                                <div class="dropdown-footer text-center">
                                    <a href="#">View All <i class="fas fa-chevron-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div> -->

                </div>
            </div>
        </div>

        <!-- table -->
        <div class="col-12">
                <div class="card">
                  <div class="card-header">
                    <h4>Data Transaksi</h4>
                    <div class="card-header-action">
                      <!-- <a href="#" onclick="openModal()" class="btn btn-info" data-target="#modal-catalog-category" data-toggle="modal">Add</a> -->
                    </div>
                  </div>
                  <div class="card-body">
                    <div class="table-responsive">
                      <table class="table table-striped" id="table-1">
                        <thead>
                          
                          <tr>
                             <th class="text-righ">Unit</th>
                                    <th class="text-righ">CIF</th>
                                    <th class="text-righ">SGE</th>
                                    <th class="text-righ">Tanggal Kredit</th>
                                    <th class="text-righ">Tanggal Tempo</th>
                                    <th class="text-righ">Tanggal Lunas</th>
                                    <th class='text-right'>Taksiran</th>
                                    <th class="text-right">UP</th>
                                    <th class='text-right'>Admin</th>
                                    <th class='text-right'>Taksiran</th>
                                    <th class="text-right">UP</th>
                                    <th class='text-right'>Admin</th>
                          </tr>
                       </thead>
                        <tbody>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
             


    </div>


</section>

<?php echo $this->endsection();?>

<?php echo $this->section('jslibraies')?>
<script src="<?php echo base_url();?>/assets-panel/bundles/apexcharts/apexcharts.min.js"></script>
<script src="<?php echo base_url();?>/assets-panel/js/modules/dashboard/index.js"></script>
<script src="<?php echo base_url();?>/assets-panel/bundles/datatables/datatables.min.js"></script>
<script src="<?php echo base_url();?>/assets-panel/bundles/datatables/DataTables-1.10.16/js/dataTables.bootstrap4.min.js">
</script>
<script src="<?php echo base_url();?>/assets-panel/bundles/jquery-ui/jquery-ui.min.js"></script>
<script src="<?php echo base_url();?>/assets-panel/bundles/sweetalert/sweetalert.min.js"></script>


<script type="text/javascript">

var months = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September',
              'Oktober',
              'November', 'Desember'
          ];

   var user_id = $('#user_id').val();
    var view_id = 8;
    axios.get(`<?php echo base_url();?>/api/dashboard/getInsertView/${user_id}/${view_id}`).then(
        res => {
            const {
                data
            } = res.data;
        }).catch(err => {
        console.log(err)
    })

      var dataTable;

        $('[name="area_id"]').on('change', function() {
        var area = $(this).val();
        var branch = document.getElementById('branch_id');
        var units = document.getElementById('units_id');
        let array = [];

         $("#branch_id").empty(); 
          $("#units_id").empty(); 
                var opt = document.createElement("option");
                    opt.value = '0';
                    opt.text = 'All';
                    branch.append(opt);
                     $("#units_id").empty(); 
                var opt = document.createElement("option");
                    opt.value = '0';
                    opt.text = 'All';
                    units.appendChild(opt);
        // var url_data = $('#url_get_cabang').val() + '/' + area;
        
        axios.get(`<?php echo base_url();?>/api/dashboard/getBranch/${area}`).then(
            res => {
                const {
                    data
                } = res.data;

                data.forEach(item => {

                    var opt = document.createElement("option");
                    opt.value = item.branch_id;
                    opt.text = item.cabang;
                    branch.appendChild(opt);
                })
            });
             category();
    });



    $('[name="branch_id"]').on('change', function() {
        var branch = $(this).val();
        var units = document.getElementById('units_id');
        let array = [];
        
         $("#units_id").empty(); 
                var opt = document.createElement("option");
                    opt.value = '0';
                    opt.text = 'All';
                    units.appendChild(opt);
        // var url_data = $('#url_get_c').val() + '/' + area;
        axios.get(`<?php echo base_url();?>/api/dashboard/getOffice/${branch}`).then(
            res => {
                const {
                    data
                } = res.data;
                data.forEach(item => {
                    var opt = document.createElement("option");
                    opt.value = item.office_id;
                    opt.text = item.name;
                    units.appendChild(opt);
                })
            });

              category();
            
    });
    
    $('[name="units_id"]').on('change', function() {
              category();
    });

    $('[name="category"]').on('change', function() {
      
      category();
    });
    $('[name="dateStart"]').on('change', function() {
              category();
    });
    $('[name="dateEnd"]').on('change', function() {
             category();
    });

    $('[name="approval"]').on('change', function() {
              category();
    });
    $('[name="deviasi"]').on('change', function() {
             category();
    });
    $('[name="limit"]').on('change', function() {
             category();
    });
    $('[name="limitRp"]').on('change', function() {
             category();
    });
    $('[name="frequensi"]').on('change', function() {
             category();
    });
    $('[name="status"]').on('change', function() {
             category();
    });
     $('[name="tiering"]').on('change', function() {
             category();
    });
    

     function approval(){
      var approval = document.getElementById('selectApproval');
        approval.style.display = "inline";
    }
    function removeApproval(){
      var approval = document.getElementById('selectApproval');
        approval.style.display = "none";
    }
    function deviasi(){
      var deviasi = document.getElementById('selectDeviasi');
        deviasi.style.display = "inline";
    }
    function removeDeviasi(){
      var deviasi = document.getElementById('selectDeviasi');
        deviasi.style.display = "none";
    }
    function limit(){
      var limit = document.getElementById('selectLimit');
        limit.style.display = "inline";
    }
    function removeLimit(){
      var limit = document.getElementById('selectLimit');
        limit.style.display = "none";
    }
    function limitRp(){
      var limitRp = document.getElementById('selectLimitRp');
        limitRp.style.display = "inline";
    }
    function removeLimitRp(){
      var limitRp = document.getElementById('selectLimitRp');
        limitRp.style.display = "none";
    }
    function frequensi(){
      var frequensi = document.getElementById('selectFrequensi');
        frequensi.style.display = "inline";
    }
    function removeFrequensi(){
      var frequensi = document.getElementById('selectFrequensi');
        frequensi.style.display = "none";
    }
    function status(){
      var status = document.getElementById('selectStatus');
        status.style.display = "inline";
    }
    function removeStatus(){
      var status = document.getElementById('selectStatus');
        status.style.display = "none";
    }
    function tiering(){
      var tiering = document.getElementById('selectTiering');
        tiering.style.display = "inline";
    }
    function removeTiering(){
      var tiering = document.getElementById('selectTiering');
        tiering.style.display = "none";
    }

    function category(){
      if($('#category').val()=='A'){ removeApproval(); removeDeviasi(); removeFrequensi(); removeStatus(); removeTiering(); limit(); initDataTable();}
       else if($('#category').val()=='B'){ removeApproval(); removeDeviasi(); removeFrequensi(); removeStatus(); removeTiering(); limit(); initDataTableB(); }
       else if($('#category').val()=='C'){ removeApproval(); removeDeviasi(); removeLimit(); removeStatus(); removeFrequensi(); removeTiering(); initDataTableC();}
       else if($('#category').val()=='D'){ removeApproval(); removeDeviasi(); removeLimit(); removeStatus(); frequensi(); removeTiering(); initDataTableD();}
       else if($('#category').val()=='E'){ removeApproval(); removeDeviasi(); removeFrequensi(); removeStatus(); limit(); removeTiering(); initDataTableE();}
       else if($('#category').val()=='F'){ removeApproval(); removeDeviasi(); removeLimit(); removeFrequensi(); removeStatus(); removeTiering(); initDataTableF();}
       else if($('#category').val()=='G'){ removeApproval(); removeDeviasi(); removeLimit(); removeFrequensi(); removeTiering(); status(); initDataTableG();}
       else if($('#category').val()=='H'){ removeApproval(); removeDeviasi(); removeLimit(); removeFrequensi(); removeStatus(); removeTiering(); initDataTableH();}
       else if($('#category').val()=='I'){ removeLimit(); removeFrequensi(); removeStatus(); removeTiering(); approval(); deviasi(); initDataTableI();}
       else if($('#category').val()=='J'){ removeLimit(); removeFrequensi(); removeStatus(); removeApproval(); removeDeviasi(); tiering(); initDataTableJ();}      
       else{ removeApproval(); removeDeviasi(); removeLimit(); removeFrequensi(); removeStatus(); removeTiering(); initDataTable();}
    }

    function convertToRupiah(angka) {
        var rupiah = '';
        var angkarev = angka.toString().split('').reverse().join('');
        for (var i = 0; i < angkarev.length; i++)
            if (i % 3 == 0) rupiah += angkarev.substr(i, 3) + '.';
        return rupiah.split('', rupiah.length - 1).reverse().join('');
    }
    function formatRupiah(angka) {
    var number_string = angka.replace(/[^,\d]/g, '').toString(),
        split = number_string.split(','),
        sisa = split[0].length % 3,
        rupiah = split[0].substr(0, sisa),
        ribuan = split[0].substr(sisa).match(/\d{3}/gi);

    // tambahkan titik jika yang di input sudah menjadi angka ribuan
    if (ribuan) {
        separator = sisa ? '.' : '';
        rupiah += separator + ribuan.join('.');
    }
    rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;
    return rupiah;
}

function formatNumber(angka) {
    var clean = angka.replace(/\D/g, '');
    return clean;
}

        const formClear =  ()=>{
          $('#modal-catalog-category').find('[name="id"]').val('');
          $('#modal-catalog-category').find('[name="level"]').val('');
          $('#modal-catalog-category').find('[name="description"]').val('');
        }
        const openModal = ()=>{
          formClear();
          
          $('#modal-catalog-category').modal('show');
        }

        $('#upload-file').on('change', function(event){
          $('#modal-catalog-category').find('.btn-save').addClass('d-none');
          let file = event.target.files[0];
          let formData = new FormData();
          formData.append('file', file);
          axios.post(`<?php echo base_url();?>/api/filedrives/upload`, formData).then(res=>{
            let id = res.data.data.id;
            $('#id_file_drive').val(id);
          }).then(res=>{
            $('#modal-catalog-category').find('.btn-save').removeClass('d-none');
          })
        });

        const submitform = (event)=>{
          event.preventDefault();
          let formData = new FormData(event.target);
          let id = $('#modal-catalog-category').find('[name="id"]').val();
          if(id === ''){
            axios.post(`<?php echo base_url();?>/api/settings/levels/insert`, formData).then(res=>{
                let status = res.data.status;
                let data = res.data.data;
                console.log('trans',data);
               if(status === 422){
                  let message = Object.values(data)[0];
                  swal('Validasi Inputan', message, 'error');
                  return;
                }
                formClear();
                dataTable.ajax.reload();
                $('#modal-catalog-category').modal('hide');
            });
          }else{
            axios.post(`<?php echo base_url();?>/api/settings/levels/updated`, formData).then(res=>{
                let status = res.data.status;
                let data = res.data.data;
                if(status === 422){
                  let message = Object.values(data)[0];
                  swal('Validasi Inputan', message, 'error');
                  return;
                }
                formClear();
                dataTable.ajax.reload();
                $('#modal-catalog-category').modal('hide');
            });
          }
        }

        // ltv > 92%
        const initDataTable = ()=>{
           var units = $('#units_id').val();
           var date = $('#date').val();
           var branch = $('#branch_id').val();
           var area = $('#area_id').val();
           let no = 0;
           var category = $('#category').val();
           var dateStart = $('#dateStart').val();
           var dateEnd = $('#dateEnd').val();
           
           var limit = $('#limit').val();
          //  if(limit == NULL){
          //   limit = 'all';
          //  }
          console.log(limit);
          console.log(dateEnd);

          dataTable = $('#table-1').DataTable( {
                // serverSide: true,
                ordering: true,
                // searching: true,
                dom: 'Bfrtip', 
                // pageLength: 25,  
                bDestroy: true,             
                ajax:  {
                    url: `<?php echo base_url();?>/api/transactions/fraud/fraud/${area}/${branch}/${units}/${category}/${dateStart}/${dateEnd}/${limit}`, 
                    // type:post,
                    dataFilter: function(data){
                        var json = jQuery.parseJSON(data);
                        json.recordsTotal = json.message.totalRecord;
                        json.recordsFiltered = json.message.totalRecord;
                        json.data = json.data;            
                        return JSON.stringify( json ); // return JSON string
                    },  
                    
                },                   
                columns: [
                      
                      { data: "area_id", title: "PT", 
                        render: function ( data, type, row ) {
                            if(data == "61611e1d8614149f281503a8" ){
                                return 'GHTS';
                            }
                            if(data == "60c6befbe64d1e2428630162" ){
                                return 'GCDA';
                            }
                            if(data == "60c6bfcce64d1e242863024a" ){
                                return 'GCAM';
                            }
                            if(data == "62280b69861414b1beffc464" ){
                                return 'GJRM';
                            }
                            if(data == "60c6bfa6e64d1e2428630213" ){
                                return 'GCTA';
                            }
                            if(data == "60c6bf2ce64d1e2428630199" ){
                                return 'GTAM III';
                            }
                            if(data == "60c6bf63e64d1e24286301d9" ){
                                return 'GTAM II';
                            }
                            if(data == "6296cca7861414086c6ba4d4" ){
                                return 'GTAM I';
                            }                            
                        }
                      },
                      { data: "office_name", title: "Unit",  },
                      { data: "month", title: "Month",
                        render: function( data, type, row ) {
                          return months[data-1];
                        }
                      },
                      { data: "year", title: "Year",  },
                      { data: "total", title: "Jumlah Trx",  },
                       {  title: 'Aksi', width: "15", 
                        data:function(data){
                          return "<td class='btn btn-info btn-edit'><a class='btn btn-info btn-edit' target='_blank'href='<?php echo base_url('fraud/detailFraud')?>/" + data.office_id + "/" +  data.month + "/" +  data.year + "/" +  data.limit + "'>Detail</a></td>";
                        }
                      },
                       { data: "total", title: "", width: "1",
                         render: function( data, type, row ) {
                          return ' ';
                        }
                      },
                      { data: "total", title: "", width: "1",
                         render: function( data, type, row ) {
                          return ' ';
                        }
                      },
                      { data: "total", title: "", width: "1",
                         render: function( data, type, row ) {
                          return ' ';
                        }
                      },
                      { data: "total", title: "", width: "1",
                         render: function( data, type, row ) {
                          return ' ';
                        }
                      },
                      { data: "total", title: "", width: "1",
                         render: function( data, type, row ) {
                          return ' ';
                        }
                      },
                      { data: "total", title: "", width: "1",
                         render: function( data, type, row ) {
                          return ' ';
                        }
                      },
                     
                  ], 
                  buttons: [
                     {
                          extend: 'copy',
                          title: 'Montly - LTV',
                          exportOptions: { orthogonal: 'export' }
                      },
                      {
                          extend: 'excel',
                          title: 'Montly - LTV',
                         exportOptions: { orthogonal: 'export' },
                         autoFilter: true,
                      },
                      {
                          extend: 'print',
                          title: 'Montly - LTV',
                           exportOptions: { orthogonal: 'export' },
                      },
                      {
                          extend: 'pdf',
                          title: 'Montly - LTV',
                           exportOptions: { orthogonal: 'export' },
                           orientation: 'landscape',
                          pageSize: 'LEGAL'
                      },
                      
                  ], 
            } );
        
        }

        // kenaikan OS > 5%
        const initDataTableB = ()=>{
           var units = $('#units_id').val();
           var date = $('#date').val();
           var branch = $('#branch_id').val();
           var area = $('#area_id').val();
           let no = 0;
           var category = $('#category').val();
           var dateStart = $('#dateStart').val();
           var dateEnd = $('#dateEnd').val();
           var limit = $('#limit').val();

          console.log(dateStart);
          console.log(dateEnd);
          var dateStartNew = new Date(dateStart);
          var dateEndNew = new Date(dateEnd);
          var months = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September',
              'Oktober',
              'November', 'Desember'
          ];

          dataTable = $('#table-1').DataTable( {
                // serverSide: true,
                ordering: true,
                // searching: true,
                dom: 'Bfrtip', 
                // pageLength: 25,  
                bDestroy: true,             
                ajax:  {
                    url: `<?php echo base_url();?>/api/transactions/fraud/outstanding/${area}/${branch}/${units}/${category}/${dateStart}/${dateEnd}/${limit}`, 
                    // type:post,
                    dataFilter: function(data){
                        var json = jQuery.parseJSON(data);
                        json.recordsTotal = json.message.totalRecord;
                        json.recordsFiltered = json.message.totalRecord;
                        json.data = json.data;            
                        return JSON.stringify( json ); // return JSON string
                    },  
                    
                },                   
                columns: [
                      
                      { data: "unit", title: "Unit"},
                      { data: "month", title: "Month",
                        render: function( data, type, row ) {
                          return months[data-1];
                        }
                      },
                      { data: "year", title: "Year" },
                      { data: "noa_1", title: "Noa Sebelumnya " ,
                        render: function ( data, type, row ) {      
                                return convertToRupiah(data);                            
                        }
                      },
                      { data: "os_1", title: "Os Sebelumnya ",
                        render: function ( data, type, row ) {      
                                return 'Rp ' + convertToRupiah(data);                            
                        }
                      },
                      { data: "noa", title: "Noa  ",
                        render: function ( data, type, row ) {      
                                return  convertToRupiah(data);                            
                        }
                      },
                      { data: "os", title: "Outstanding  ",
                        render: function ( data, type, row ) {      
                                return 'Rp ' + convertToRupiah(data);                            
                        }
                      },
                      { data: "persentase", title: "Persentase",
                        render: function(data, type, row){
                          return row.persentase.toFixed(2) + " %";
                        }
                      },
                      {  title: 'Aksi', 
                        data:function(data){
                          return "<td class='btn btn-info btn-edit'><a class='btn btn-info btn-edit' target='_blank'href='<?php echo base_url('fraud/detail')?>/" + data.office_id + "/" +  data.date + "'>Detail</a></td>";
                        }
                      },
                      { data: "os", title: "", width: "1",
                         render: function( data, type, row ) {
                          return ' ';
                        }
                      },
                      { data: "os", title: "", width: "1",
                         render: function( data, type, row ) {
                          return ' ';
                        }
                      },
                      { data: "os", title: "", width: "1",
                         render: function( data, type, row ) {
                          return ' ';
                        }
                      },
                      
                      
                      
                  ], 
                  buttons: [
                     {
                          extend: 'copy',
                          title: 'Monthly - Outstanding',
                          exportOptions: { orthogonal: 'export' }
                      },
                      {
                          extend: 'excel',
                          title: 'Monthly - Outstanding',
                         exportOptions: { orthogonal: 'export' },
                         autoFilter: true,
                      },
                      {
                          extend: 'print',
                          title: 'Monthly - Outstanding',
                           exportOptions: { orthogonal: 'export' },
                      },
                      {
                          extend: 'pdf',
                          title: 'Monthly - Outstanding',
                           exportOptions: { orthogonal: 'export' },
                           orientation: 'landscape',
                          pageSize: 'LEGAL'
                      },
                      
                  ], 
            } );
        
        }

        // TicketSize 
        const initDataTableC = ()=>{
           var units = $('#units_id').val();
           var date = $('#date').val();
           var branch = $('#branch_id').val();
           var area = $('#area_id').val();
           let no = 0;
           var category = $('#category').val();
           var dateStart = $('#dateStart').val();
           var dateEnd = $('#dateEnd').val();
           var limitRp = $('#limitRp').val();

          console.log(dateStart);
          console.log(dateEnd);
          var dateStartNew = new Date(dateStart);
          var dateEndNew = new Date(dateEnd);
          var months = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September',
              'Oktober',
              'November', 'Desember'
          ];

          dataTable = $('#table-1').DataTable( {
                // serverSide: true,
                ordering: true,
                // searching: true,
                dom: 'Bfrtip', 
                // pageLength: 25,  
                bDestroy: true,             
                ajax:  {
                    url: `<?php echo base_url();?>/api/transactions/fraud/ticketsize/${area}/${branch}/${units}/${category}/${dateStart}/${dateEnd}/${limitRp}`, 
                    // type:post,
                    dataFilter: function(data){
                        var json = jQuery.parseJSON(data);
                        json.recordsTotal = json.message.totalRecord;
                        json.recordsFiltered = json.message.totalRecord;
                        json.data = json.data;            
                        return JSON.stringify( json ); // return JSON string
                    },  
                    
                },                   
                columns: [
                      
                      { data: "area_id", title: "PT",
                        render: function ( data, type, row ) {
                            if(data == "61611e1d8614149f281503a8" ){
                                return 'GHTS';
                            }
                            if(data == "60c6befbe64d1e2428630162" ){
                                return 'GCDA';
                            }
                            if(data == "60c6bfcce64d1e242863024a" ){
                                return 'GCAM';
                            }
                            if(data == "62280b69861414b1beffc464" ){
                                return 'GJRM';
                            }
                            if(data == "60c6bfa6e64d1e2428630213" ){
                                return 'GCTA';
                            }
                            if(data == "60c6bf2ce64d1e2428630199" ){
                                return 'GTAM III';
                            }
                            if(data == "60c6bf63e64d1e24286301d9" ){
                                return 'GTAM II';
                            }
                            if(data == "6296cca7861414086c6ba4d4" ){
                                return 'GTAM I';
                            }                            
                        }
                      },
                      { data: "office_name", title: "Unit" },
                      { data: "month", title: "Month",
                        render: function( data, type, row ) {
                          return months[data-1];
                        }
                      },
                      { data: "year", title: "Year" },
                      { data: "noa", title: " Noa" },
                      { data: "up", title: "UP",
                        render: function ( data, type, row ) {      
                                return 'Rp ' + convertToRupiah(data);                            
                        }
                      },
                      { data: "ticketsize", title: " Ticketsize" ,
                        render: function ( data, type, row ) {      
                                return 'Rp ' + convertToRupiah(data);                            
                        }
                      },
                       {  title: 'Aksi', 
                        data:function(data){
                          return "<td class='btn btn-info btn-edit'><a class='btn btn-info btn-edit' target='_blank'href='<?php echo base_url('fraud/detailTicketsize')?>/" + data.office_id + "/" +  data.month + "/" +  data.year + "'>Detail</a></td>";
                        }
                      },
                      { data: "ticketsize", title: "", width: "1",
                         render: function( data, type, row ) {
                          return ' ';
                        }
                      },
                      { data: "ticketsize", title: "", width: "1",
                         render: function( data, type, row ) {
                          return ' ';
                        }
                      },
                      { data: "ticketsize", title: "", width: "1",
                         render: function( data, type, row ) {
                          return ' ';
                        }
                      },
                      { data: "ticketsize", title: "", width: "1",
                         render: function( data, type, row ) {
                          return ' ';
                        }
                      },
                      
                      
                  ], 
                  buttons: [
                     {
                          extend: 'copy',
                          title: 'Monthly - Ticketsize',
                          exportOptions: { orthogonal: 'export' }
                      },
                      {
                          extend: 'excel',
                          title: 'Monthly - Ticketsize',
                         exportOptions: { orthogonal: 'export' },
                         autoFilter: true,
                      },
                      {
                          extend: 'print',
                          title: 'Monthly - Ticketsize',
                           exportOptions: { orthogonal: 'export' },
                      },
                      {
                          extend: 'pdf',
                          title: 'Monthly - Ticketsize',
                           exportOptions: { orthogonal: 'export' },
                           orientation: 'landscape',
                          pageSize: 'LEGAL'
                      },
                      
                  ], 
            } );
        
        }

         // frequensi transactions 
        const initDataTableD = ()=>{
           var units = $('#units_id').val();
           var date = $('#date').val();
           var branch = $('#branch_id').val();
           var area = $('#area_id').val();
           let no = 0;
           var category = $('#category').val();
           var dateStart = $('#dateStart').val();
           var dateEnd = $('#dateEnd').val();
           var frequensi = $('#frequensi').val();
          console.log(dateStart);
          console.log(dateEnd);
          var dateStartNew = new Date(dateStart);
          var dateEndNew = new Date(dateEnd);
          var months = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September',
              'Oktober',
              'November', 'Desember'
          ];

          dataTable = $('#table-1').DataTable( {
                // serverSide: true,
                ordering: true,
                // searching: true,
                dom: 'Bfrtip', 
                // pageLength: 25,  
                bDestroy: true,             
                ajax:  {
                    url: `<?php echo base_url();?>/api/transactions/fraud/frequensi/${area}/${branch}/${units}/${category}/${dateStart}/${dateEnd}/${frequensi}`, 
                    // type:post,
                    dataFilter: function(data){
                        var json = jQuery.parseJSON(data);
                        json.recordsTotal = json.message.totalRecord;
                        json.recordsFiltered = json.message.totalRecord;
                        json.data = json.data;            
                        return JSON.stringify( json ); // return JSON string
                    },  
                    
                },                   
                columns: [
                  
                  { data: "area_id", title: "PT",
                        render: function ( data, type, row ) {
                            if(data == "61611e1d8614149f281503a8" ){
                                return 'GHTS';
                            }
                            if(data == "60c6befbe64d1e2428630162" ){
                                return 'GCDA';
                            }
                            if(data == "60c6bfcce64d1e242863024a" ){
                                return 'GCAM';
                            }
                            if(data == "62280b69861414b1beffc464" ){
                                return 'GJRM';
                            }
                            if(data == "60c6bfa6e64d1e2428630213" ){
                                return 'GCTA';
                            }
                            if(data == "60c6bf2ce64d1e2428630199" ){
                                return 'GTAM III';
                            }
                            if(data == "60c6bf63e64d1e24286301d9" ){
                                return 'GTAM II';
                            }
                            if(data == "6296cca7861414086c6ba4d4" ){
                                return 'GTAM I';
                            }
                            
                        }
                        },
                      { data: "office_name", title: "Unit" },
                      { data: "month", title: "Month",
                        render: function( data, type, row ) {
                          return months[data-1];
                        }
                      },
                      { data: "year", title: "Year" },
                      { data: "cif_number", title: "No CIF" },
                      { data: "name", title: "Nasabah" },
                      { data: "identity_number", title: "KTP" },
                      // { data: "phone_number", title: "No Handphone" },
                      { data: "noa", title: "Total trx" },
                      { data: "up", title: "Total UP",
                        render: function ( data, type, row ) {      
                                return 'Rp ' + convertToRupiah(data);                            
                        }
                      },
                      
                      {
                        data:function(data){
                          return "<td class='btn btn-info btn-edit'><a class='btn btn-info btn-edit' target='_blank'href='<?php echo base_url('fraud/detail_frequensi')?>/" + data.office_id + "/" +  data.identity_number + "/" +  data.month + "/" +  data.year + "'>Detail</a></td>";
                          // return `   <button  onclick="detail_frequensi(${data.identity_number})" class="btn btn-info btn-edit">Detail</button>
                          //             `;
                        }
                      },
                      
                      { data: "up", title: "", width: "1",
                         render: function( data, type, row ) {
                          return ' ';
                        }
                      },
                      { data: "up", title: "", width: "1",
                         render: function( data, type, row ) {
                          return ' ';
                        }
                      },
                      
                      
                  ], 
                  buttons: [
                     {
                          extend: 'copy',
                          title: 'Monthly - Frequensi Transaksi',
                          exportOptions: { orthogonal: 'export' }
                      },
                      {
                          extend: 'excel',
                          title: 'Monthly - Frequensi Transaksi',
                         exportOptions: { orthogonal: 'export' },
                         autoFilter: true,
                      },
                      {
                          extend: 'print',
                          title: 'Monthly - Frequensi Transaksi',
                           exportOptions: { orthogonal: 'export' },
                      },
                      {
                          extend: 'pdf',
                          title: 'Monthly - Frequensi Transaksi',
                           exportOptions: { orthogonal: 'export' },
                           orientation: 'landscape',
                          pageSize: 'LEGAL'
                      },
                      
                  ], 
            } );
        
        }

         // kenaikan DPD > 5%
        const initDataTableE = ()=>{
           var units = $('#units_id').val();
           var date = $('#date').val();
           var branch = $('#branch_id').val();
           var area = $('#area_id').val();
           let no = 0;
           var category = $('#category').val();
           var dateStart = $('#dateStart').val();
           var dateEnd = $('#dateEnd').val();
           var limit = $('#limit').val();
          console.log(dateStart);
          console.log(dateEnd);
          var dateStartNew = new Date(dateStart);
          var dateEndNew = new Date(dateEnd);
          var months = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September',
              'Oktober',
              'November', 'Desember'
          ];

          dataTable = $('#table-1').DataTable( {
                // serverSide: true,
                ordering: true,
                // searching: true,
                dom: 'Bfrtip', 
                // pageLength: 25,  
                bDestroy: true,             
                ajax:  {
                    url: `<?php echo base_url();?>/api/transactions/fraud/dpd/${area}/${branch}/${units}/${category}/${dateStart}/${dateEnd}/${limit}`, 
                    // type:post,
                    dataFilter: function(data){
                        var json = jQuery.parseJSON(data);
                        json.recordsTotal = json.message.totalRecord;
                        json.recordsFiltered = json.message.totalRecord;
                        json.data = json.data;            
                        return JSON.stringify( json ); // return JSON string
                    },  
                    
                },                   
                columns: [
                      
                      { data: "unit", title: "Unit"},
                      { data: "month", title: "Month",
                        render: function( data, type, row ) {
                          return months[data-1];
                        }
                      },
                      { data: "year", title: "Year" },
                      { data: "noa_os", title: "Noa OS " ,
                        // render: function ( data, type, row ) {      
                        //         return convertToRupiah(data);                            
                        // }
                      },
                      { data: "outstanding", title: "Outstanding ",
                        // render: function ( data, type, row ) {      
                        //         return 'Rp ' + convertToRupiah(data);                            
                        // }
                      },
                      { data: "noa_1", title: "Noa Sebelumnya " ,
                        render: function ( data, type, row ) {      
                                return convertToRupiah(data);                            
                        }
                      },
                      { data: "os_1", title: "DPD Sebelumnya ",
                        render: function ( data, type, row ) {      
                                return 'Rp ' + convertToRupiah(data);                            
                        }
                      },
                      { data: "noa", title: "Noa  ",
                        render: function ( data, type, row ) {      
                                return  convertToRupiah(data);                            
                        }
                      },
                      { data: "os", title: "DPD  ",
                        render: function ( data, type, row ) {      
                                return 'Rp ' + convertToRupiah(data);                            
                        }
                      },
                      { data: "persentase_os", title: "% ( OS )",
                        render: function(data, type, row){
                          return row.persentase_os.toFixed(2) + " %";
                        }
                      },
                       { data: "persentase", title: "% ( kenaikan )",
                        render: function(data, type, row){
                          return row.persentase.toFixed(2) + " %";
                        }
                      },
                      {  title: 'Aksi', 
                        data:function(data){
                          return "<td class='btn btn-info btn-edit'><a class='btn btn-info btn-edit' target='_blank'href='<?php echo base_url('fraud/detail_dpd')?>/" + data.office_id + "/" +  data.date + "'>Detail</a></td>";
                        }
                      },
                      
                      
                  ], 
                  buttons: [
                     {
                          extend: 'copy',
                          title: 'Monthly - DPD',
                          exportOptions: { orthogonal: 'export' }
                      },
                      {
                          extend: 'excel',
                          title: 'Monthly - DPD',
                         exportOptions: { orthogonal: 'export' },
                         autoFilter: true,
                      },
                      {
                          extend: 'print',
                          title: 'Monthly - DPD',
                           exportOptions: { orthogonal: 'export' },
                      },
                      {
                          extend: 'pdf',
                          title: 'Monthly - DPD',
                           exportOptions: { orthogonal: 'export' },
                           orientation: 'landscape',
                          pageSize: 'LEGAL'
                      },
                      
                  ], 
            } );
        
        }

         // Moker 
        const initDataTableF = ()=>{
           var units = $('#units_id').val();
           var date = $('#date').val();
           var branch = $('#branch_id').val();
           var area = $('#area_id').val();
           let no = 0;
           var category = $('#category').val();
           var dateStart = $('#dateStart').val();
           var dateEnd = $('#dateEnd').val();
          console.log(dateStart);
          console.log(dateEnd);
          var dateStartNew = new Date(dateStart);
          var dateEndNew = new Date(dateEnd);
          var months = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September',
              'Oktober',
              'November', 'Desember'
          ];

          dataTable = $('#table-1').DataTable( {
                // serverSide: true,
                ordering: true,
                // searching: true,
                dom: 'Bfrtip', 
                // pageLength: 25,  
                bDestroy: true,             
                ajax:  {
                    url: `<?php echo base_url();?>/api/transactions/fraud/moker/${area}/${branch}/${units}/${category}/${dateStart}/${dateEnd}`, 
                    // type:post,
                    dataFilter: function(data){
                        var json = jQuery.parseJSON(data);
                        json.recordsTotal = json.message.totalRecord;
                        json.recordsFiltered = json.message.totalRecord;
                        json.data = json.data;            
                        return JSON.stringify( json ); // return JSON string
                    },  
                    
                },                   
                columns: [
                      
                      { data: "area_name", title: "PT"},
                      { data: "office_name", title: "Unit "},
                      { data: "month", title: "Month ",
                        render: function( data, type, row ) {
                          return months[data-1];
                        }
                      },
                      { data: "year", title: "Year"},
                      {  data: "moker", title: "Total Moker",
                        render: function ( data, type, row ) {      
                                return "<td class='text-right'>Rp " + convertToRupiah(data) + "</td>";                            
                        }
                      },
                      {  data: "jumlah", title: "Jumlah (x)",
                       
                      },
                      
                      {  title: 'Aksi', 
                        data:function(data){
                          return "<td class='btn btn-info btn-edit'><a class='btn btn-info btn-edit' target='_blank'href='<?php echo base_url('fraud/detailMoker')?>/" + data.office_id + "/" +  data.month + "/" +  data.year + "'>Detail</a></td>";
                        }
                      },
                       { data: "moker", title: "", width: "1",
                         render: function( data, type, row ) {
                          return ' ';
                        }
                      },
                       { data: "moker", title: "", width: "1",
                         render: function( data, type, row ) {
                          return ' ';
                        }
                      },
                      { data: "moker", title: "", width: "1",
                         render: function( data, type, row ) {
                          return ' ';
                        }
                      },
                      { data: "moker", title: "", width: "1",
                         render: function( data, type, row ) {
                          return ' ';
                        }
                      },
                      { data: "moker", title: "", width: "1",
                         render: function( data, type, row ) {
                          return ' ';
                        }
                      },
                      
                      
                  ], 
                  buttons: [
                     {
                          extend: 'copy',
                          title: 'Monthly - Modal Kerja',
                          exportOptions: { orthogonal: 'export' }
                      },
                      {
                          extend: 'excel',
                          title: 'Monthly - Modal Kerja',
                         exportOptions: { orthogonal: 'export' },
                         autoFilter: true,
                      },
                      {
                          extend: 'print',
                          title: 'Monthly - Modal Kerja',
                           exportOptions: { orthogonal: 'export' },
                      },
                      {
                          extend: 'pdf',
                          title: 'Monthly - Modal Kerja',
                           exportOptions: { orthogonal: 'export' },
                           orientation: 'landscape',
                          pageSize: 'LEGAL'
                      },
                      
                  ], 
            } );
        
        }

  

         // Saldo Kas 
        const initDataTableG = ()=>{
          var saldolimit = 0;
          var status = document.getElementById('status');
          status.addEventListener('keyup', function(e) {
            var saldo = document.getElementById('status');
            saldo.value = formatRupiah(saldo.value);

            var saldolimit = $("#status").val();

            if (saldolimit) {
                saldolimit = formatNumber(saldolimit);
            } else {
                saldolimit = 0;
            }
            console.log('Saldo',saldolimit);
              
          });
          var saldolimit = $("#status").val();

            if (saldolimit) {
                saldolimit = formatNumber(saldolimit);
            } else {
                saldolimit = 0;
            }
           var units = $('#units_id').val();
           var date = $('#date').val();
           var branch = $('#branch_id').val();
           var area = $('#area_id').val();
           let no = 0;
           var category = $('#category').val();
           var dateStart = $('#dateStart').val();
           var dateEnd = $('#dateEnd').val();
           var status = $('#status').val();
           
          console.log(dateStart);
          console.log(dateEnd);
          var dateStartNew = new Date(dateStart);
          var dateEndNew = new Date(dateEnd);
          var months = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September',
              'Oktober',
              'November', 'Desember'
          ];

          dataTable = $('#table-1').DataTable( {
                ordering: true,
                dom: 'Bfrtip', 
                bDestroy: true,             
                ajax:  {
                    url: `<?php echo base_url();?>/api/transactions/fraud/saldokas/${area}/${branch}/${units}/${category}/${dateStart}/${dateEnd}/${saldolimit}`, 
                    // type:post,
                    dataFilter: function(data){
                        var json = jQuery.parseJSON(data);
                        json.recordsTotal = json.message.totalRecord;
                        json.recordsFiltered = json.message.totalRecord;
                        json.data = json.data;            
                        return JSON.stringify( json ); // return JSON string
                    },  
                    
                },                   
                columns: [
                      
                      { data: "area_id", title: "PT", 
                        render: function ( data, type, row ) {
                            if(data == "61611e1d8614149f281503a8" ){
                                return 'GHTS';
                            }
                            if(data == "60c6befbe64d1e2428630162" ){
                                return 'GCDA';
                            }
                            if(data == "60c6bfcce64d1e242863024a" ){
                                return 'GCAM';
                            }
                            if(data == "62280b69861414b1beffc464" ){
                                return 'GJRM';
                            }
                            if(data == "60c6bfa6e64d1e2428630213" ){
                                return 'GCTA';
                            }
                            if(data == "60c6bf2ce64d1e2428630199" ){
                                return 'GTAM III';
                            }
                            if(data == "60c6bf63e64d1e24286301d9" ){
                                return 'GTAM II';
                            }
                            if(data == "6296cca7861414086c6ba4d4" ){
                                return 'GTAM I';
                            }                            
                        }
                        },
                      { data: "office_name", title: "Unit "},
                      { data: "office_code", title: "Code "},
                      { data: "date_open", title: "Date"},
                      { data: "saldo", title: "Pagukas", 
                        render: function ( data, type, row ) {      
                                return "<td class='text-right'>Rp " + convertToRupiah(data) + "</td>";                            
                        }
                      },
                      {  data: "remaining_balance", title: "Saldo Akhir", 
                        render: function ( data, type, row ) {      
                                return "<td class='text-right'>Rp " + convertToRupiah(data) + "</td>";                            
                        }
                      },

                      { data: "status", title: "Status",
                        render: function ( data, type, row ) {  
                          if(data == 0){
                            return "<div class='badge badge-info badge-shadow'>Dibawah</div>";
                          }else{    
                            return "<div class='badge badge-danger badge-shadow'>Diatas</div>";                            
                          }
                        }
                      },
                      
                      { data: "percentase", title: "Percentase", 
                        render: function ( data, type, row ) {      
                                return data.toFixed(2) + "%";                            
                        }
                      },
                      { data: "percentase", title: "",
                        render: function(data, type, row){
                          return " ";
                        }
                      },
                      { data: "percentase", title: "", width: "1",
                         render: function( data, type, row ) {
                          return ' ';
                        }
                      },
                      { data: "percentase", title: "", width: "1",
                         render: function( data, type, row ) {
                          return ' ';
                        }
                      },
                      { data: "percentase", title: "", width: "1",
                         render: function( data, type, row ) {
                          return ' ';
                        }
                      },
                      
                      
                  ], 
                  buttons: [
                     {
                          extend: 'copy',
                          title: 'Monthly - Saldo Kas',
                          exportOptions: { orthogonal: 'export' }
                      },
                      {
                          extend: 'excel',
                          title: 'Monthly - Saldo Kas',
                         exportOptions: { orthogonal: 'export' },
                         autoFilter: true,
                      },
                      {
                          extend: 'print',
                          title: 'Monthly - Saldo Kas',
                           exportOptions: { orthogonal: 'export' },
                      },
                      {
                          extend: 'pdf',
                          title: 'Monthly - Saldo Kas',
                           exportOptions: { orthogonal: 'export' },
                           orientation: 'landscape',
                          pageSize: 'LEGAL'
                      },
                      
                  ], 
            } );
        
        }

        // Transaksi Batal
        const initDataTableH = ()=>{
           var units = $('#units_id').val();
           var date = $('#date').val();
           var branch = $('#branch_id').val();
           var area = $('#area_id').val();
           let no = 0;
           var category = $('#category').val();
           var dateStart = $('#dateStart').val();
           var dateEnd = $('#dateEnd').val();
          console.log(dateStart);
          console.log(dateEnd);

          dataTable = $('#table-1').DataTable( {
                // serverSide: true,
                ordering: true,
                // searching: true,
                dom: 'Bfrtip', 
                // pageLength: 25,  
                bDestroy: true,             
                ajax:  {
                    url: `<?php echo base_url();?>/api/transactions/fraud/trxBatal/${area}/${branch}/${units}/${category}/${dateStart}/${dateEnd}`, 
                    // type:post,
                    dataFilter: function(data){
                        var json = jQuery.parseJSON(data);
                        json.recordsTotal = json.message.totalRecord;
                        json.recordsFiltered = json.message.totalRecord;
                        json.data = json.data;            
                        return JSON.stringify( json ); // return JSON string
                    },  
                    
                },                   
                columns: [
                      
                      // { data: "office_name", title: "No"},
                      { data: "area_id", title: "PT",
                        render: function ( data, type, row ) {
                            if(data == "61611e1d8614149f281503a8" ){
                                return 'GHTS';
                            }
                            if(data == "60c6befbe64d1e2428630162" ){
                                return 'GCDA';
                            }
                            if(data == "60c6bfcce64d1e242863024a" ){
                                return 'GCAM';
                            }
                            if(data == "62280b69861414b1beffc464" ){
                                return 'GJRM';
                            }
                            if(data == "60c6bfa6e64d1e2428630213" ){
                                return 'GCTA';
                            }
                            if(data == "60c6bf2ce64d1e2428630199" ){
                                return 'GTAM III';
                            }
                            if(data == "60c6bf63e64d1e24286301d9" ){
                                return 'GTAM II';
                            }
                            if(data == "6296cca7861414086c6ba4d4" ){
                                return 'GTAM I';
                            }                            
                        }
                      },
                      { data: "office_name", title: "Unit" },
                      { data: "month", title: "Month",
                        render: function( data, type, row ) {
                          return months[data-1];
                        }
                      },
                      { data: "year", title: "Year" },
                      { data: "up", title: "Total Pinjaman",
                        render: function ( data, type, row ) {      
                                return "<td class='text-right'>Rp " + convertToRupiah(data) + "</td>";                            
                        }
                      },
                      { data: "total", title: "Jumlah Trx" },
                      
                       {  title: 'Aksi', 
                        data:function(data){
                          return "<td class='btn btn-info btn-edit'><a class='btn btn-info btn-edit' target='_blank'href='<?php echo base_url('fraud/detailTrxBatal')?>/" + data.office_id + "/" +  data.month + "/" +  data.year + "'>Detail</a></td>";
                        }
                      },
                      
                      { data: "year", title: "", width: "1",
                         render: function( data, type, row ) {
                          return ' ';
                        }
                      },
                      { data: "year", title: "", width: "1",
                         render: function( data, type, row ) {
                          return ' ';
                        }
                      },
                      { data: "year", title: "", width: "1",
                         render: function( data, type, row ) {
                          return ' ';
                        }
                      },
                      { data: "year", title: "", width: "1",
                         render: function( data, type, row ) {
                          return ' ';
                        }
                      },
                      { data: "year", title: "", width: "1",
                         render: function( data, type, row ) {
                          return ' ';
                        }
                      },
                      
                  ], 
                  buttons: [
                     {
                          extend: 'copy',
                          title: 'Monthly - Pembatalan Transaksi',
                          exportOptions: { orthogonal: 'export' }
                      },
                      {
                          extend: 'excel',
                          title: 'Monthly - Pembatalan Transaksi',
                         exportOptions: { orthogonal: 'export' },
                         autoFilter: true,
                      },
                      {
                          extend: 'print',
                          title: 'Monthly - Pembatalan Transaksi',
                           exportOptions: { orthogonal: 'export' },
                      },
                      {
                          extend: 'pdf',
                          title: 'Monthly - Pembatalan Transaksi',
                           exportOptions: { orthogonal: 'export' },
                           orientation: 'landscape',
                          pageSize: 'LEGAL'
                      },
                      
                  ], 
            } );
        
        }

         //  Deviasi & Approval
        const initDataTableI = ()=>{
           var units = $('#units_id').val();
           var date = $('#date').val();
           var branch = $('#branch_id').val();
           var area = $('#area_id').val();
           let no = 0;
           var category = $('#category').val();
           var dateStart = $('#dateStart').val();
           var dateEnd = $('#dateEnd').val();
          
          var dateStartNew = new Date(dateStart);
          var dateEndNew = new Date(dateEnd);
          var approval = $('#approval').val();
          var deviasi = $('#deviasi').val();
          var months = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September',
              'Oktober',
              'November', 'Desember'
          ];

          dataTable = $('#table-1').DataTable( {
                // serverSide: true,
                ordering: true,
                // searching: true,
                dom: 'Bfrtip', 
                // pageLength: 25,  
                bDestroy: true,             
                ajax:  {
                    url: `<?php echo base_url();?>/api/transactions/fraud/approval/${area}/${branch}/${units}/${category}/${dateStart}/${dateEnd}/${approval}/${deviasi}`, 
                    // type:post,
                    // data:{approval:approval, deviasi:deviasi},
                    dataFilter: function(data){
                        var json = jQuery.parseJSON(data);
                        json.recordsTotal = json.message.totalRecord;
                        json.recordsFiltered = json.message.totalRecord;
                        json.data = json.data;            
                        return JSON.stringify( json ); // return JSON string
                    },  
                    
                },                   
                columns: [
                  
                  { data: "area_id", title: "PT",
                        render: function ( data, type, row ) {
                            if(data == "61611e1d8614149f281503a8" ){
                                return 'GHTS';
                            }
                            if(data == "60c6befbe64d1e2428630162" ){
                                return 'GCDA';
                            }
                            if(data == "60c6bfcce64d1e242863024a" ){
                                return 'GCAM';
                            }
                            if(data == "62280b69861414b1beffc464" ){
                                return 'GJRM';
                            }
                            if(data == "60c6bfa6e64d1e2428630213" ){
                                return 'GCTA';
                            }
                            if(data == "60c6bf2ce64d1e2428630199" ){
                                return 'GTAM III';
                            }
                            if(data == "60c6bf63e64d1e24286301d9" ){
                                return 'GTAM II';
                            }
                            if(data == "6296cca7861414086c6ba4d4" ){
                                return 'GTAM I';
                            }
                            
                        }
                        },
                        { data: "office_name", title: "Unit" },
                      { data: "month", title: "Month",
                        render: function( data, type, row ) {
                          // console.log(row);
                          // console.log(type);
                          // console.log(data);
                          return months[data-1];

                        }
                      },
                      { data: "year", title: "Year" },
                      { data: "deviasi", title: "Deviasi",
                        render: function( data, type, row ) {
                          if(data == "all"){ data = "All"; }
                          if(data == "0"){ data = "LTV"; }
                          if(data == "1"){ data = "Sewa"; }
                          if(data == "2"){ data = "Admin"; }
                          if(data == "3"){ data = "One Obligor"; }
                          if(data == "5"){ data = "Limit Transaksi"; }
                          return data;
                        }
                      },
                      { data: "approval", title: "Approval",
                        render: function( data, type, row ) {
                          if(data == "all"){ data = "All"; }
                          if(data == "0"){ data = "Cabang"; }
                          if(data == "1"){ data = "Area"; }
                          if(data == "2"){ data = "Regional"; }
                          if(data == "3"){ data = "Pusat"; }
                          return data;
                        }
                      },
                      { data: "jumlah", title: "Jumlah" },
                      
                      
                      {
                        data:function(data){
                          return "<td class='btn btn-info btn-edit'><a class='btn btn-info btn-edit' target='_blank'href='<?php echo base_url('fraud/detailApproval')?>/" + data.office_id + "/" +  data.month + "/" +  data.year + "/" +  data.approval + "/" +  data.deviasi + "'>Detail</a></td>";
                        
                        }
                      },
                      
                      { data: "jumlah", title: "", width: "1",
                         render: function( data, type, row ) {
                          return ' ';
                        }
                      },

                      { data: "jumlah", title: "", width: "1",
                         render: function( data, type, row ) {
                          return ' ';
                        }
                      },
                      { data: "jumlah", title: "", width: "1",
                         render: function( data, type, row ) {
                          return ' ';
                        }
                      },
                      { data: "jumlah", title: "", width: "1",
                         render: function( data, type, row ) {
                          return ' ';
                        }
                      },
                      
                      
                  ], 
                  buttons: [
                     {
                          extend: 'copy',
                          title: 'Monthly - Deviasi & Approval',
                          exportOptions: { orthogonal: 'export' }
                      },
                      {
                          extend: 'excel',
                          title: 'Monthly - Deviasi & Approval',
                         exportOptions: { orthogonal: 'export' },
                         autoFilter: true,
                      },
                      {
                          extend: 'print',
                          title: 'Monthly - Deviasi & Approval',
                           exportOptions: { orthogonal: 'export' },
                      },
                      {
                          extend: 'pdf',
                          title: 'Monthly - Deviasi & Approval',
                           exportOptions: { orthogonal: 'export' },
                           orientation: 'landscape',
                          pageSize: 'LEGAL'
                      },
                      
                  ], 
            } );
        
        }

        //Oneobligor',
        const initDataTableJ = ()=>{

           //
           var units = $('#units_id').val();
           var date = $('#date').val();
           var branch = $('#branch_id').val();
           var area = $('#area_id').val();
           let no = 0;
           var tiering = $('#tiering').val();
           var dateStart = $('#dateStart').val();
           var dateEnd = $('#dateEnd').val();
          
          var dateStartNew = new Date(dateStart);
          var dateEndNew = new Date(dateEnd);
          var approval = $('#approval').val();
          var deviasi = $('#deviasi').val();
          var months = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September',
              'Oktober',
              'November', 'Desember'
          ];

          dataTable = $('#table-1').DataTable( {
                // serverSide: true,
                ordering: true,
                // searching: true,
                dom: 'Bfrtip', 
                // pageLength: 25,  
                bDestroy: true,             
                ajax:  {
                    url: `<?php echo base_url();?>/api/transactions/fraud/oneobligor/${area}/${branch}/${units}/${dateStart}/${dateEnd}/${tiering}`, 
                    // type:post,
                    dataFilter: function(data){
                        var json = jQuery.parseJSON(data);
                        json.recordsTotal = json.message.totalRecord;
                        json.recordsFiltered = json.message.totalRecord;
                        json.data = json.data;            
                        return JSON.stringify( json ); // return JSON string
                    },  
                   
                },                   
                columns: [
                      
                      { data: "area_id", title: "PT",
                        render: function ( data, type, row ) {
                            if(data == "61611e1d8614149f281503a8" ){
                                return 'GHTS';
                            }
                            if(data == "60c6befbe64d1e2428630162" ){
                                return 'GCDA';
                            }
                            if(data == "60c6bfcce64d1e242863024a" ){
                                return 'GCAM';
                            }
                            if(data == "62280b69861414b1beffc464" ){
                                return 'GJRM';
                            }
                            if(data == "60c6bfa6e64d1e2428630213" ){
                                return 'GCTA';
                            }
                            if(data == "60c6bf2ce64d1e2428630199" ){
                                return 'GTAM III';
                            }
                            if(data == "60c6bf63e64d1e24286301d9" ){
                                return 'GTAM II';
                            }
                            if(data == "6296cca7861414086c6ba4d4" ){
                                return 'GTAM I';
                            }
                            
                        }
                      },
                      { data: "office_name", title: "Unit"},
                      { data: "cif_number", title: "CIF"},
                      { data: "customer_name", title: "Nasabah"},
                      { data: "identity_number", title: "No KTP"},
                      { data: "phone_number", title: "No Handphone"},
                      { data: "noa", title: "Noa"},
                      { data: "up", title: "Total UP",
                        render: function ( data, type, row ) {      
                                return 'Rp ' + convertToRupiah(data);                            
                        }
                      },
                      
                      {
                        data:function(data){
                          return `   <button  onclick="detailOneobligor(${data.identity_number})" class="btn btn-info btn-edit">Detail</button>
                                      `;
                        }
                      },
                      { data: "up", title: "", width: "1",
                         render: function( data, type, row ) {
                          return ' ';
                        }
                      },
                      { data: "up", title: "", width: "1",
                         render: function( data, type, row ) {
                          return ' ';
                        }
                      },
                      { data: "up", title: "", width: "1",
                         render: function( data, type, row ) {
                          return ' ';
                        }
                      },

                  ], 
                  buttons: [
                     {
                          extend: 'copy',
                          title: 'Monthly - Oneobligor',
                          exportOptions: { orthogonal: 'export' }
                      },
                      {
                          extend: 'excel',
                          title: 'Monthly - Oneobligor',
                         exportOptions: { orthogonal: 'export' },
                         autoFilter: true,
                      },
                      {
                          extend: 'print',
                          title: 'Monthly - Oneobligor',
                           exportOptions: { orthogonal: 'export' },
                      },
                      {
                          extend: 'pdf',
                          title: 'Monthly - Oneobligor',
                           exportOptions: { orthogonal: 'export' },
                           orientation: 'landscape',
                          pageSize: 'LEGAL'
                      },
                      
                  ], 
            } );

          
        }

        const detailOneobligor = (identity_number)=>{
          window.open('<?php echo base_url();?>/fraud/detailOneobligor/' + identity_number, '_blank');

          // axios.get(`<?php echo base_url();?>/api/settings/levels/view/${identity_number}`).then(res=>{
          //   $('#modal-catalog-category').find('[name="id"]').val(res.data.data.identity_number);
          //   $('#modal-catalog-category').find('[name="level"]').val(res.data.data.level);
          //   $('#modal-catalog-category').find('[name="description"]').val(res.data.data.description);
          //   }).then(res=>  $('#modal-catalog-category').modal('show'))
        }

        const detail = (office_id, date)=>{
          console.log(office_id, date);
          window.open('<?php echo base_url();?>/fraud/detail/' + office_id + '/' + dateEnd, '_blank');
        }
        const detail_frequensi = (office_id, date)=>{
          console.log(office_id, date);
          window.open('<?php echo base_url();?>/fraud/detail_frequensi/' + office_id + '/' + dateEnd, '_blank');
        }

        const btnDelete = (id)=>{
          axios.get(`<?php echo base_url();?>/api/settings/levels/view/${id}`).then(res=>{
              swal({
              title: 'Are you sure?',
              text: `Once deleted, you will not be able to recover ${res.data.data.level}!`,
              icon: 'warning',
              buttons: true,
              dangerMode: true,
            }).then((willDelete) => {
                if (willDelete) {
                  axios.get(`<?php echo base_url();?>/api/settings/levels/deleted/${id}`).then(res=>{
                    swal(`Poof! ${res.data.data.level} has been deleted!`, {
                      icon: 'success',
                    });
                    dataTable.ajax.reload();
                  });
                } else {
                  swal('Your imaginary file is safe!');
                }
              });
          })
          
        }

  

        const btnHistory = (id)=>{
          url = `<?php echo base_url();?>/api/settings/levelshistories?id_price_lm=${id}`;
          dataTableHistory.ajax.url(url).load();
          $('#modal-history').modal('show');
        }

        initDataTable();
    </script>

<!-- Add New Javascript -->
<script>
// function chartOs() {
    // Select option
    

        


</script>

<?php echo $this->endSection();?>