<?php echo $this->extend('layouts/administrator');?>

<?php echo $this->section('content');?>

<section class="section">

    <div class="row ">

        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="card card-danger">
                <div class="card-header">
                    <div class="col-lg-2">
                        <select class="form-control" name="area_id" id="area_id">
                            <option value="0">Select Area</option>
                            <?php foreach($areas as $area){ ?>
                            <option value="<?php echo $area->area_id; ?>"><?php echo $area->area; ?></option>
                            </option>
                            <?php  } ?>
                        </select>
                    </div>
                    <div class="col-lg-2">
                        <select class="form-control" name="branch_id" id="branch_id">
                            <option value="0">Select Cabang</option>
                        </select>
                        <input type="hidden" name="user_id" id="user_id" value="<?php echo session('user')->id ?>" />

                    </div>
                    <div class="col-lg-2">
                        <select class="form-control" name="units_id" id="units_id">
                            <option value="0">Select Units</option>
                        </select>

                    </div>

                    <div class="col-lg-2">
                        <select class="form-control" name="category" id="category">
                            <option value="0">Select Category</option>
                            <option value="A">Up 10rb - 20jt</option>
                            <option value="B">Up 20,01jt - 50jt</option>
                            <option value="C">Up 50,01jt - 100jt</option>
                            <option value="D">Up 100,01jt - 150jt</option>
                            <option value="E">Up 150,01jt - 250jt</option>
                              <option value="F">Up 250,01 - 2M</option>
                        </select>

                    </div>

                    <div class="card-header-action">
                        <div id="count" class="dropdown dropdown-list-toggle">
                            <a href="#" data-toggle="dropdown" class="nav-link nav-link-lg message-toggle"><i
                                    data-feather="eye"></i>
                                <!-- <span id="count" class="badge headerBadge1">
                                    6 </span> -->
                            </a>
                            <div class="dropdown-menu dropdown-list dropdown-menu-right pullDown">
                                <div class="dropdown-header">
                                    Dilihat Oleh:
                                    <div class="float-right">
                                        <!-- <a href="#">Dilihat oleh :</a> -->
                                    </div>
                                </div>
                                <div class="dropdown-list-content dropdown-list-message">

                                    <?php foreach($view as $views){ 
                                        
                                //         $awal  = $views->updated_at;
                                // $akhir = now(); // waktu sekarang
                                // $diff  = date_diff( $awal, $akhir );
                                ?>
                                    <a href="#" class="dropdown-item"> <span class="dropdown-item-desc"> <span
                                                class="message-user"><?php echo $views->username; ?></span>
                                            <!-- <span class="time messege-text">Please check your mail !!</span> -->
                                            <span class="time">
                                                <?php //echo $diff->d;?> hari yang lalu
                                            </span>
                                        </span>
                                    </a>
                                    <?php } ?>
                                </div>
                                <div class="dropdown-footer text-center">
                                    <a href="#">View All <i class="fas fa-chevron-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>

        <!-- table -->
        <div class="col-12">
                <div class="card">
                  <div class="card-header">
                    <h4>Data Oneobligor</h4>
                    <div class="card-header-action">
                      <!-- <a href="#" onclick="openModal()" class="btn btn-info" data-target="#modal-catalog-category" data-toggle="modal">Add</a> -->
                    </div>
                  </div>
                  <div class="card-body">
                    <div class="table-responsive">
                      <table class="table table-striped" id="table-1">
                        <thead>
                          <!-- <tr>
                            <th class="filterhead">Area</th>
                            <th class="filterhead">Branch</th>
                            <th class="filterhead">Units</th>
                          </tr> -->
                          <tr>
                            <th class="text-center">PT</th>
                                    <th class="text-center">Unit</th>
                                    <th class="text-center">CIF</th>
                                    <th>Nasabah</th>
                                    <th class="text-center">No KTP</th>
                                    <th class="text-center">No Handphone</th>
                                    <th class="text-center">Noa</th>
                                    <th class="text-center">Total UP</th>
                                    <th class='text-center'>Aksi</th>
                          </tr>
                        </thead>
                        <tbody>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
             


    </div>


</section>

<?php echo $this->endsection();?>

<?php echo $this->section('jslibraies')?>
<script src="<?php echo base_url();?>/assets-panel/bundles/apexcharts/apexcharts.min.js"></script>
<script src="<?php echo base_url();?>/assets-panel/js/modules/dashboard/index.js"></script>
<script src="<?php echo base_url();?>/assets-panel/bundles/datatables/datatables.min.js"></script>
<script src="<?php echo base_url();?>/assets-panel/bundles/datatables/DataTables-1.10.16/js/dataTables.bootstrap4.min.js">
</script>
<script src="<?php echo base_url();?>/assets-panel/bundles/jquery-ui/jquery-ui.min.js"></script>
<script src="<?php echo base_url();?>/assets-panel/bundles/sweetalert/sweetalert.min.js"></script>


<script type="text/javascript">

   var user_id = $('#user_id').val();
    var view_id = 8;
    axios.get(`<?php echo base_url();?>/api/dashboard/getInsertView/${user_id}/${view_id}`).then(
        res => {
            const {
                data
            } = res.data;
        }).catch(err => {
        console.log(err)
    })

      var dataTable;

        $('[name="area_id"]').on('change', function() {
        var area = $(this).val();
        var branch = document.getElementById('branch_id');
        var units = document.getElementById('units_id');
        let array = [];

        // var url_data = $('#url_get_cabang').val() + '/' + area;
        
        axios.get(`<?php echo base_url();?>/api/dashboard/getBranch/${area}`).then(
            res => {
                const {
                    data
                } = res.data;
                // console.log('test');
                // console.log(build);
                // $("#branch_id").empty();
                $("#branch_id").empty(); 
                $("#units_id").empty();
                branch.append('<option value="0">Select Branch</option>');

                data.forEach(item => {

                    var opt = document.createElement("option");
                    opt.value = item.branch_id;
                    opt.text = item.cabang;
                    branch.appendChild(opt);


                })
            });
            initDataTable();
    });



    $('[name="branch_id"]').on('change', function() {
        var branch = $(this).val();
        var units = document.getElementById('units_id');
        let array = [];
        
        // var url_data = $('#url_get_c').val() + '/' + area;
        axios.get(`<?php echo base_url();?>/api/dashboard/getOffice/${branch}`).then(
            res => {
                const {
                    data
                } = res.data;
                
                // units.append('<option value="0">All</option>');
                $("#units_id").empty();

                data.forEach(item => {
                    var opt = document.createElement("option");
                    opt.value = item.office_id;
                    opt.text = item.name;
                    units.appendChild(opt);


                })
            });

            initDataTable();
    });
    
    $('[name="units_id"]').on('change', function() {
            initDataTable();
    });

    $('[name="category"]').on('change', function() {
            initDataTable();
    });

    function convertToRupiah(angka) {
        var rupiah = '';
        var angkarev = angka.toString().split('').reverse().join('');
        for (var i = 0; i < angkarev.length; i++)
            if (i % 3 == 0) rupiah += angkarev.substr(i, 3) + '.';
        return rupiah.split('', rupiah.length - 1).reverse().join('');
    }

        const formClear =  ()=>{
          $('#modal-catalog-category').find('[name="id"]').val('');
          $('#modal-catalog-category').find('[name="level"]').val('');
          $('#modal-catalog-category').find('[name="description"]').val('');
        }
        const openModal = ()=>{
          formClear();
          
          $('#modal-catalog-category').modal('show');
        }

        $('#upload-file').on('change', function(event){
          $('#modal-catalog-category').find('.btn-save').addClass('d-none');
          let file = event.target.files[0];
          let formData = new FormData();
          formData.append('file', file);
          axios.post(`<?php echo base_url();?>/api/filedrives/upload`, formData).then(res=>{
            let id = res.data.data.id;
            $('#id_file_drive').val(id);
          }).then(res=>{
            $('#modal-catalog-category').find('.btn-save').removeClass('d-none');
          })
        });

        const submitform = (event)=>{
          event.preventDefault();
          let formData = new FormData(event.target);
          let id = $('#modal-catalog-category').find('[name="id"]').val();
          if(id === ''){
            axios.post(`<?php echo base_url();?>/api/settings/levels/insert`, formData).then(res=>{
                let status = res.data.status;
                let data = res.data.data;
                console.log('trans',data);
               if(status === 422){
                  let message = Object.values(data)[0];
                  swal('Validasi Inputan', message, 'error');
                  return;
                }
                formClear();
                dataTable.ajax.reload();
                $('#modal-catalog-category').modal('hide');
            });
          }else{
            axios.post(`<?php echo base_url();?>/api/settings/levels/updated`, formData).then(res=>{
                let status = res.data.status;
                let data = res.data.data;
                if(status === 422){
                  let message = Object.values(data)[0];
                  swal('Validasi Inputan', message, 'error');
                  return;
                }
                formClear();
                dataTable.ajax.reload();
                $('#modal-catalog-category').modal('hide');
            });
          }
        }

        const initDataTable = ()=>{
           var units = $('#units_id').val();
           var date = $('#date').val();
           var branch = $('#branch_id').val();
           var area = $('#area_id').val();
           let no = 0;
           var category = $('#category').val();

          dataTable = $('#table-1').DataTable( {
                // serverSide: true,
                ordering: true,
                // searching: true,
                dom: 'Bfrtip', 
                // pageLength: 25,  
                bDestroy: true,             
                ajax:  {
                    url: `<?php echo base_url();?>/api/transactions/oneobligor/oneobligor/${area}/${branch}/${units}/${category}`, 
                    // type:post,
                    dataFilter: function(data){
                        var json = jQuery.parseJSON(data);
                        json.recordsTotal = json.message.totalRecord;
                        json.recordsFiltered = json.message.totalRecord;
                        json.data = json.data;            
                        return JSON.stringify( json ); // return JSON string
                    },  
                    // type:POST,
                    // data:{
                    //   area:$('#area_id').val(),
                    //   branch:$('#branch_id').val(),
                    //   units:$('#units_id').val(),
                    //   category:$('#category').val(),
                    // }
                },                   
                columns: [
                      
                      { data: "area_id",
                        render: function ( data, type, row ) {
                            if(data == "61611e1d8614149f281503a8" ){
                                return 'GHTS';
                            }
                            if(data == "60c6befbe64d1e2428630162" ){
                                return 'GCDA';
                            }
                            if(data == "60c6bfcce64d1e242863024a" ){
                                return 'GCAM';
                            }
                            if(data == "62280b69861414b1beffc464" ){
                                return 'GJRM';
                            }
                            if(data == "60c6bfa6e64d1e2428630213" ){
                                return 'GCTA';
                            }
                            if(data == "60c6bf2ce64d1e2428630199" ){
                                return 'GTAM III';
                            }
                            if(data == "60c6bf63e64d1e24286301d9" ){
                                return 'GTAM II';
                            }
                            if(data == "6296cca7861414086c6ba4d4" ){
                                return 'GTAM I';
                            }
                            
                        }
                        },
                      { data: "office_name" },
                      { data: "cif_number" },
                      { data: "customer_name" },
                      { data: "identity_number" },
                      { data: "phone_number" },
                      { data: "noa" },
                      { data: "up",
                        render: function ( data, type, row ) {      
                                return 'Rp ' + convertToRupiah(data);                            
                        }
                      },
                      
                      {
                        data:function(data){
                          return `   <button  onclick="detail(${data.identity_number})" class="btn btn-info btn-edit">Detail</button>
                                      `;
                        }
                      }
                  ], 
                  buttons: [
                     {
                          extend: 'copy',
                          title: 'Monitoring - Data Oneobligor',
                          exportOptions: { orthogonal: 'export' }
                      },
                      {
                          extend: 'excel',
                          title: 'Monitoring - Data Oneobligor',
                         exportOptions: { orthogonal: 'export' },
                         autoFilter: true,
                      },
                      {
                          extend: 'print',
                          title: 'Monitoring - Data Oneobligor',
                           exportOptions: { orthogonal: 'export' },
                      },
                      {
                          extend: 'pdf',
                          title: 'Monitoring - Data Oneobligor',
                           exportOptions: { orthogonal: 'export' },
                           orientation: 'landscape',
                          pageSize: 'LEGAL'
                      },
                      
                  ], 
            } );

          //   $(".filterhead").(':eq(4)').each(function( i ){
          //     var select = $('<select><option value=""></option></select>')
          //     .appendTo( $(this).empty() )
          //     .on('change', function() {
          //       var term = $(this).val();
          //       table.column( i ).search( term, false, false ).draw();
          //     });
          //     table.column( i ).data().unique().sort().each(function( d, j){
          //       select.append( '<option value="'+d+'">'+d+'</option>' );
          //   });
          // });
        
        }

        const btnDelete = (id)=>{
          axios.get(`<?php echo base_url();?>/api/settings/levels/view/${id}`).then(res=>{
              swal({
              title: 'Are you sure?',
              text: `Once deleted, you will not be able to recover ${res.data.data.level}!`,
              icon: 'warning',
              buttons: true,
              dangerMode: true,
            }).then((willDelete) => {
                if (willDelete) {
                  axios.get(`<?php echo base_url();?>/api/settings/levels/deleted/${id}`).then(res=>{
                    swal(`Poof! ${res.data.data.level} has been deleted!`, {
                      icon: 'success',
                    });
                    dataTable.ajax.reload();
                  });
                } else {
                  swal('Your imaginary file is safe!');
                }
              });
          })
          
        }

        const detail = (identity_number)=>{
          window.open('<?php echo base_url();?>/monitoring/oneobligor/detail/' + identity_number, '_blank');

          // axios.get(`<?php echo base_url();?>/api/settings/levels/view/${identity_number}`).then(res=>{
          //   $('#modal-catalog-category').find('[name="id"]').val(res.data.data.identity_number);
          //   $('#modal-catalog-category').find('[name="level"]').val(res.data.data.level);
          //   $('#modal-catalog-category').find('[name="description"]').val(res.data.data.description);
          //   }).then(res=>  $('#modal-catalog-category').modal('show'))
        }

        const btnHistory = (id)=>{
          url = `<?php echo base_url();?>/api/settings/levelshistories?id_price_lm=${id}`;
          dataTableHistory.ajax.url(url).load();
          $('#modal-history').modal('show');
        }

        initDataTable();
    </script>

<!-- Add New Javascript -->
<script>
// function chartOs() {
    // Select option
    

        


</script>

<?php echo $this->endSection();?>